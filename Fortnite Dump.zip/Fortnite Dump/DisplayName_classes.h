// WidgetBlueprintGeneratedClass DisplayName.DisplayName_C
// Size: 0x520 (Inherited: 0x508)
struct UDisplayName_C : UFortDisplayNameWidget {
	struct UCommonBorder* DisplayNameBorder; // 0x508(0x08)
	struct UEditableText* EditText_Number; // 0x510(0x08)
	struct UVerticalBox* VBox_Number; // 0x518(0x08)
};


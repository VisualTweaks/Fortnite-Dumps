// BlueprintGeneratedClass Border-MainL.Border-MainL_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-MainL_C : UCommonBorderStyle {
};


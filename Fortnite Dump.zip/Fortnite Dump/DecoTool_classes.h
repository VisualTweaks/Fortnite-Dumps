// BlueprintGeneratedClass DecoTool.DecoTool_C
// Size: 0x14b0 (Inherited: 0x14b0)
struct ADecoTool_C : AFortDecoTool {
};


// BlueprintGeneratedClass B_Shotgun_Ostrich_test.B_Shotgun_Ostrich_test_C
// Size: 0x1ab0 (Inherited: 0x1a80)
struct AB_Shotgun_Ostrich_test_C : AFortWeaponRanged_Ostrich {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1a80(0x08)
	struct USoundBase* Sound_LoadMissile; // 0x1a88(0x08)
	struct USoundBase* Sound_RocketFire; // 0x1a90(0x08)
	struct UForceFeedbackEffect* RocketFireForceFeedback; // 0x1a98(0x08)
	struct UForceFeedbackEffect* RocketLoadForceFeedback; // 0x1aa0(0x08)
	struct UForceFeedbackEffect* ShotgunFireForceFeedback; // 0x1aa8(0x08)

	void OnLoadedRockets(int32_t NumRocketsLoaded); // Function B_Shotgun_Ostrich_test.B_Shotgun_Ostrich_test_C.OnLoadedRockets // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnRocketFired(struct USceneComponent* AttachToMesh, struct FName AttachToSocket); // Function B_Shotgun_Ostrich_test.B_Shotgun_Ostrich_test_C.OnRocketFired // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnRocketLauncherSettle(struct USceneComponent* AttachToMesh, struct FName AttachToSocket); // Function B_Shotgun_Ostrich_test.B_Shotgun_Ostrich_test_C.OnRocketLauncherSettle // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnRocketFiringStarted(struct USceneComponent* AttachToMesh, struct FName AttachToSocket); // Function B_Shotgun_Ostrich_test.B_Shotgun_Ostrich_test_C.OnRocketFiringStarted // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnPlayWeaponFireFX(bool bPersistentFire, bool bSecondaryFire); // Function B_Shotgun_Ostrich_test.B_Shotgun_Ostrich_test_C.OnPlayWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_B_Shotgun_Ostrich_test(int32_t EntryPoint); // Function B_Shotgun_Ostrich_test.B_Shotgun_Ostrich_test_C.ExecuteUbergraph_B_Shotgun_Ostrich_test // (Final|UbergraphFunction) // @ game+0xd6d38c
};


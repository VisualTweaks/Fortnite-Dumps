// BlueprintGeneratedClass EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C
// Size: 0x2a60 (Inherited: 0x2730)
struct AEnemyPawn_Parent_Deimos_C : AFortAIPawn {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2730(0x08)
	struct USoundLibraryComponent* SoundLibrary; // 0x2738(0x08)
	struct UCapsuleComponent* WeaponCapsuleCollision; // 0x2740(0x08)
	struct UAudioComponent* Elemental_Layer_Audio_Loop; // 0x2748(0x08)
	float Enemy_Spawn_Out_TL_ColorFadeOutTrack_37A083E44F5772C5FFF36680D2AD7D94; // 0x2750(0x04)
	float Enemy_Spawn_Out_TL_FadeInTrack_37A083E44F5772C5FFF36680D2AD7D94; // 0x2754(0x04)
	enum class ETimelineDirection Enemy_Spawn_Out_TL__Direction_37A083E44F5772C5FFF36680D2AD7D94; // 0x2758(0x01)
	char pad_2759[0x7]; // 0x2759(0x07)
	struct UTimelineComponent* Enemy Spawn Out TL; // 0x2760(0x08)
	float EnemySpawnInTL_ColorFadeOutTrack_515E6B424789F427A1B9ACAD857FFF5D; // 0x2768(0x04)
	float EnemySpawnInTL_FadeInTrack_515E6B424789F427A1B9ACAD857FFF5D; // 0x276c(0x04)
	enum class ETimelineDirection EnemySpawnInTL__Direction_515E6B424789F427A1B9ACAD857FFF5D; // 0x2770(0x01)
	char pad_2771[0x7]; // 0x2771(0x07)
	struct UTimelineComponent* EnemySpawnInTL; // 0x2778(0x08)
	struct FTransform SpawnParticlesTransform; // 0x2780(0x30)
	struct UParticleSystem* SpawnParticles; // 0x27b0(0x08)
	struct UParticleSystemComponent* CharacterElementalParticles; // 0x27b8(0x08)
	bool AllowHeadshot; // 0x27c0(0x01)
	char pad_27C1[0x7]; // 0x27c1(0x07)
	struct FGameplayTagContainer TC_RangedWeapon; // 0x27c8(0x20)
	struct UParticleSystemComponent* HeadshotParticleSystemComp; // 0x27e8(0x08)
	struct UAnimMontage* Additive Hit React Montage; // 0x27f0(0x08)
	struct USoundBase* Death Normal Sound; // 0x27f8(0x08)
	struct USoundBase* Elemental_Audio_Layer_Sound; // 0x2800(0x08)
	struct FName Headshot FX Socket; // 0x2808(0x08)
	struct TMap<struct USkeletalMeshComponent*, struct UFXSkeletonMeshComponent_C*> AwakenFXSkeletalMeshes; // 0x2810(0x50)
	struct TMap<struct UStaticMeshComponent*, struct UFXStaticMeshComponent_C*> AwakenFXStaticMeshes; // 0x2860(0x50)
	float AwokenMaxDistance; // 0x28b0(0x04)
	float AwakenDuration; // 0x28b4(0x04)
	struct FTimerHandle DestroyAwakenFXTimer; // 0x28b8(0x08)
	struct TMap<struct USkeletalMeshComponent*, struct UFXSkeletonMeshComponent_C*> BuildingHitFXSkeletalMeshes; // 0x28c0(0x50)
	struct TMap<struct UStaticMeshComponent*, struct UFXStaticMeshComponent_C*> BuildingHitFXStaticMeshes; // 0x2910(0x50)
	float BuildingHitDuration; // 0x2960(0x04)
	char pad_2964[0x4]; // 0x2964(0x04)
	struct FTimerHandle DestroyBuildingHitFXTimer; // 0x2968(0x08)
	struct UFXSkeletonMeshComponent_C* TempFXSkeletalMesh; // 0x2970(0x08)
	struct TArray<struct USkeletalMeshComponent*> RegisteredSkeletalMeshesForEffects; // 0x2978(0x10)
	struct TArray<struct UStaticMeshComponent*> RegisteredStaticMeshesForEffects; // 0x2988(0x10)
	bool HasGlowColorsAssigned; // 0x2998(0x01)
	bool SpawnInTimelineCompletedSuccessfully; // 0x2999(0x01)
	char pad_299A[0x6]; // 0x299a(0x06)
	struct FTimerHandle CharacterSpawnInSafetyCheckHandle; // 0x29a0(0x08)
	struct TArray<struct UMaterialInstanceDynamic*> Previous MID; // 0x29a8(0x10)
	struct UParticleSystem* CharacterAmbientParticlesTemplate; // 0x29b8(0x08)
	struct UParticleSystemComponent* CharacterAmbientParticles; // 0x29c0(0x08)
	struct USkeletalMeshComponent* DuplicateCharacterMesh; // 0x29c8(0x08)
	struct UMaterialInstanceDynamic* DuplicateCharacterMID; // 0x29d0(0x08)
	struct TArray<struct UObject*> Auxillary Objects; // 0x29d8(0x10)
	struct TArray<struct UObject*> Duplicate Auxillary Objects; // 0x29e8(0x10)
	struct UParticleSystemComponent* MinibossPSComponent; // 0x29f8(0x08)
	float CharacterParticlesMaxDrawDistance; // 0x2a00(0x04)
	char pad_2A04[0x4]; // 0x2a04(0x04)
	struct TArray<struct UPhysicalMaterial*> Original Phys Material; // 0x2a08(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> Previous MID_AuxObjs; // 0x2a18(0x10)
	int32_t Restoring Array Index; // 0x2a28(0x04)
	bool UseHeadShotFX; // 0x2a2c(0x01)
	char pad_2A2D[0x3]; // 0x2a2d(0x03)
	struct USoundBase* Death_Dematerialize_Sound; // 0x2a30(0x08)
	struct USoundBase* HeadShot_Sound; // 0x2a38(0x08)
	float AdditiveHitReactRetriggerDelay; // 0x2a40(0x04)
	struct FGameplayTag GC_SidewaysSpawnFx; // 0x2a44(0x08)
	char pad_2A4C[0x4]; // 0x2a4c(0x04)
	struct USimpleSoundLibraryContext* SoundLibraryContext; // 0x2a50(0x08)
	struct FGameplayTag GC_OnSpawnFX; // 0x2a58(0x08)

	void Orphaned(bool& IsOrphaned, struct AFortPawn*& AttachedPawn); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.Orphaned // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void PlaySoundLibraryAudio(struct FGameplayTag Event Name); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.PlaySoundLibraryAudio // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void DeregisterEffectSkeletalMesh(struct USkeletalMeshComponent* Mesh); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.DeregisterEffectSkeletalMesh // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void DeregisterEffectStaticMesh(struct UStaticMeshComponent* Mesh); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.DeregisterEffectStaticMesh // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ApplyAwakenEffectToStaticMesh(struct UStaticMeshComponent* Mesh); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.ApplyAwakenEffectToStaticMesh // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ApplyAwakenEffectToSkeletalMesh(struct USkeletalMeshComponent* Mesh); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.ApplyAwakenEffectToSkeletalMesh // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void RegisterEffectStaticMesh(struct UStaticMeshComponent* Mesh); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.RegisterEffectStaticMesh // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void RegisterEffectSkeletalMesh(struct USkeletalMeshComponent* Mesh); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.RegisterEffectSkeletalMesh // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ApplyBuildingHitEffectToStaticMesh(struct UStaticMeshComponent* Mesh); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.ApplyBuildingHitEffectToStaticMesh // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ApplyBuildingHitEffectToSkeletalMesh(struct USkeletalMeshComponent* Mesh); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.ApplyBuildingHitEffectToSkeletalMesh // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void CharacterSpawnInSafetyCheck(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.CharacterSpawnInSafetyCheck // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SpawnParticleSystemOnCharacterMesh(struct UParticleSystem* ParticleSystemTemplate, struct UParticleSystemComponent* ParticleSystemComponentReferenceVar, struct FName AttachPointName, struct FVector Location, struct FRotator Rotation, struct TArray<struct FParticleSysParam>& InstanceParameters, bool AutoActivate, bool AutoDestroy, bool AbsoluteLocation, bool AbsoluteRotation, bool AbsoluteScale, struct UParticleSystemComponent*& PSComponentReference); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.SpawnParticleSystemOnCharacterMesh // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void PlayAdditiveHitReacts(struct FVector Hit Direction, struct UAnimMontage* Anim Montage); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.PlayAdditiveHitReacts // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SetScalarParameterOnAllCharacterMIDs(struct FName Parameter Name, float Scalar Value, bool AlsoModifyOriginalMIDs); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.SetScalarParameterOnAllCharacterMIDs // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SetVectorParameterOnAllCharacterMIDs(struct FName Parameter Name, struct FVector Vector Value, bool Propagate to Auxiliary Meshes); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.SetVectorParameterOnAllCharacterMIDs // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void UserConstructionScript(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Enemy Spawn Out TL__FinishedFunc(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.Enemy Spawn Out TL__FinishedFunc // (BlueprintEvent) // @ game+0xd6d38c
	void Enemy Spawn Out TL__UpdateFunc(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.Enemy Spawn Out TL__UpdateFunc // (BlueprintEvent) // @ game+0xd6d38c
	void EnemySpawnInTL__FinishedFunc(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.EnemySpawnInTL__FinishedFunc // (BlueprintEvent) // @ game+0xd6d38c
	void EnemySpawnInTL__UpdateFunc(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.EnemySpawnInTL__UpdateFunc // (BlueprintEvent) // @ game+0xd6d38c
	void EnemySpawnInTL__Spawn__EventFunc(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.EnemySpawnInTL__Spawn__EventFunc // (BlueprintEvent) // @ game+0xd6d38c
	void OnBeginDance(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.OnBeginDance // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnEndDance(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.OnEndDance // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void TriggerDeathFX(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.TriggerDeathFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveBeginPlay(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnBeginDeepWaterInteraction(struct FVector WaterSurfaceLocation, float WaterDepth); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.OnBeginDeepWaterInteraction // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnWaterDeepNavMeshEnter(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.OnWaterDeepNavMeshEnter // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnDeathPlayEffects(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.OnDeathPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void ManualDespawnEnemy(struct FVector RiftLocationWS); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.ManualDespawnEnemy // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ManualEnemySpawnIn(struct FVector RiftLocationWS); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.ManualEnemySpawnIn // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SpawnInSafetyCheck(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.SpawnInSafetyCheck // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void PostSpawnIn(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.PostSpawnIn // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void DespawnEnemy(struct FVector RiftLocationWS); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.DespawnEnemy // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void DebugEnemySpawnIn(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.DebugEnemySpawnIn // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnFinishedEncounterSpawn(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.OnFinishedEncounterSpawn // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnStartedEncounterSpawn(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.OnStartedEncounterSpawn // (BlueprintCosmetic|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnDamagePlayEffects(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.OnDamagePlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void AdditiveHitReactDelay(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.AdditiveHitReactDelay // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void DestroyBuildingHitEffect(); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.DestroyBuildingHitEffect // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnBuildingHitPlayEffects(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct FGameplayEffectContextHandle EffectContext, bool bPlayerPlaced); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.OnBuildingHitPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_EnemyPawn_Parent_Deimos(int32_t EntryPoint); // Function EnemyPawn_Parent_Deimos.EnemyPawn_Parent_Deimos_C.ExecuteUbergraph_EnemyPawn_Parent_Deimos // (Final|UbergraphFunction|HasDefaults) // @ game+0xd6d38c
};


// BlueprintGeneratedClass ButtonStyle-MediumTransparentWithCues.ButtonStyle-MediumTransparentWithCues_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-MediumTransparentWithCues_C : UButtonStyle-MediumTransparentNoCues_C {
};


// BlueprintGeneratedClass ButtonStyle-Skew.ButtonStyle-Skew_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Skew_C : UCommonButtonStyle {
};


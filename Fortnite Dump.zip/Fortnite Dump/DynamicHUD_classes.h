// Class DynamicHUD.DynamicHUDDirectorBase
// Size: 0x230 (Inherited: 0x220)
struct ADynamicHUDDirectorBase : AActor {
	struct TArray<struct UDynamicHUDScene*> DefaultScenes; // 0x220(0x10)
};

// Class DynamicHUD.DynamicHUDConstraintOverrideBase
// Size: 0x28 (Inherited: 0x28)
struct UDynamicHUDConstraintOverrideBase : UObject {
};

// Class DynamicHUD.DynamicHUDConstraintBase
// Size: 0x78 (Inherited: 0x28)
struct UDynamicHUDConstraintBase : UObject {
	char pad_28[0x38]; // 0x28(0x38)
	struct FVector2D Offset; // 0x60(0x08)
	struct UDynamicHUDConstraintOverrideBase* ConstraintOverride; // 0x68(0x08)
	char bUseOffset : 1; // 0x70(0x01)
	char bUseOverride : 1; // 0x70(0x01)
	char pad_70_2 : 6; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class DynamicHUD.DynamicHUDConstraintPosition
// Size: 0x88 (Inherited: 0x78)
struct UDynamicHUDConstraintPosition : UDynamicHUDConstraintBase {
	struct FVector2D Position; // 0x78(0x08)
	enum class EDynamicHUDAnchor Anchor; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
};

// Class DynamicHUD.DynamicHUDConstraintAlignment
// Size: 0x80 (Inherited: 0x78)
struct UDynamicHUDConstraintAlignment : UDynamicHUDConstraintBase {
	enum class EHorizontalAlignment HorizontalAlignment; // 0x78(0x01)
	enum class EVerticalAlignment VerticalAlignment; // 0x79(0x01)
	char pad_7A[0x2]; // 0x7a(0x02)
	enum class EDynamicHUDAnchor Anchor; // 0x7c(0x04)
};

// Class DynamicHUD.DynamicHUDConstraintWidget
// Size: 0xd0 (Inherited: 0x78)
struct UDynamicHUDConstraintWidget : UDynamicHUDConstraintBase {
	enum class EDynamicHUDAnchor Anchor; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct TSoftClassPtr<UObject> TargetWidget; // 0x80(0x28)
	struct FName TargetUniqueID; // 0xa8(0x08)
	enum class EDynamicHUDAnchor TargetAnchor; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct TArray<struct FDynamicHUDConstraintWidgetFallback> Fallbacks; // 0xb8(0x10)
	char bUseFallbacks : 1; // 0xc8(0x01)
	char pad_C8_1 : 7; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
};

// Class DynamicHUD.DynamicHUDManager
// Size: 0x148 (Inherited: 0x30)
struct UDynamicHUDManager : UWorldSubsystem {
	char pad_30[0x50]; // 0x30(0x50)
	struct TMap<struct UDynamicHUDScene*, struct FContextData> ActiveScenes; // 0x80(0x50)
	char pad_D0[0x28]; // 0xd0(0x28)
	struct TMap<struct FString, struct FDirectorData> ActiveDirectors; // 0xf8(0x50)

	void RemoveScenes(struct TArray<struct UDynamicHUDScene*> Scenes, struct UObject* OptionalContext); // Function DynamicHUD.DynamicHUDManager.RemoveScenes // (Final|Native|Protected|BlueprintCallable) // @ game+0x69ef2ec
	void RemoveScene(struct UDynamicHUDScene* Scene, struct UObject* OptionalContext); // Function DynamicHUD.DynamicHUDManager.RemoveScene // (Final|Native|Protected|BlueprintCallable) // @ game+0x69ef024
	void AddScenes(struct TArray<struct UDynamicHUDScene*> Scenes, struct UObject* OptionalContext); // Function DynamicHUD.DynamicHUDManager.AddScenes // (Final|Native|Protected|BlueprintCallable) // @ game+0x69eeea8
	void AddScene(struct UDynamicHUDScene* Scene, struct UObject* OptionalContext); // Function DynamicHUD.DynamicHUDManager.AddScene // (Final|Native|Protected|BlueprintCallable) // @ game+0x69eec44
};

// Class DynamicHUD.DynamicHUDScene
// Size: 0x50 (Inherited: 0x30)
struct UDynamicHUDScene : UDataAsset {
	struct TArray<struct FDynamicHUDAllowed> Allowed; // 0x30(0x10)
	struct TArray<struct FDynamicHUDUnallowed> Unallowed; // 0x40(0x10)
};

// Class DynamicHUD.DynamicHUDVisualizerWidget
// Size: 0x288 (Inherited: 0x260)
struct UDynamicHUDVisualizerWidget : UUserWidget {
	struct TArray<struct UDynamicHUDScene*> Scenes; // 0x260(0x10)
	bool bRefresh; // 0x270(0x01)
	char pad_271[0x17]; // 0x271(0x17)
};


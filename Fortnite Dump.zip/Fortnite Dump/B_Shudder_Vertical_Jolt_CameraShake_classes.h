// BlueprintGeneratedClass B_Shudder_Vertical_Jolt_CameraShake.B_Shudder_Vertical_Jolt_CameraShake_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UB_Shudder_Vertical_Jolt_CameraShake_C : UMatineeCameraShake {
};


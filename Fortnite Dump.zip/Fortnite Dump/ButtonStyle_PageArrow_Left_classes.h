// BlueprintGeneratedClass ButtonStyle_PageArrow_Left.ButtonStyle_PageArrow_Left_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle_PageArrow_Left_C : UButtonStyle-MediumTransparentNoCues_C {
};


// WidgetBlueprintGeneratedClass ControllerActionsMenuEntry.ControllerActionsMenuEntry_C
// Size: 0xc28 (Inherited: 0xc28)
struct UControllerActionsMenuEntry_C : UFortControllerActionsMenuEntry {
};


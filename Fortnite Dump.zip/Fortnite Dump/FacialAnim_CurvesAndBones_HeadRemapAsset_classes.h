// BlueprintGeneratedClass FacialAnim_CurvesAndBones_HeadRemapAsset.FacialAnim_CurvesAndBones_HeadRemapAsset_C
// Size: 0x30 (Inherited: 0x30)
struct UFacialAnim_CurvesAndBones_HeadRemapAsset_C : UFacialLiveLinkRemapAsset {
};


// Class AbilitySystemGameFeatureActions.GameFeatureAction_AddAttributeDefaults
// Size: 0x38 (Inherited: 0x28)
struct UGameFeatureAction_AddAttributeDefaults : UGameFeatureAction {
	struct TArray<struct FSoftObjectPath> AttribDefaultTableNames; // 0x28(0x10)
};


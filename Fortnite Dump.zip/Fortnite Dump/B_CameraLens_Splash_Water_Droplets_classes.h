// BlueprintGeneratedClass B_CameraLens_Splash_Water_Droplets.B_CameraLens_Splash_Water_Droplets_C
// Size: 0x2e8 (Inherited: 0x2e0)
struct AB_CameraLens_Splash_Water_Droplets_C : AEmitterCameraLensEffectBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e0(0x08)

	void ReceiveBeginPlay(); // Function B_CameraLens_Splash_Water_Droplets.B_CameraLens_Splash_Water_Droplets_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_B_CameraLens_Splash_Water_Droplets(int32_t EntryPoint); // Function B_CameraLens_Splash_Water_Droplets.B_CameraLens_Splash_Water_Droplets_C.ExecuteUbergraph_B_CameraLens_Splash_Water_Droplets // (Final|UbergraphFunction) // @ game+0xd6d38c
};


// BlueprintGeneratedClass Border-ItemInfo-Header.Border-ItemInfo-Header_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-ItemInfo-Header_C : UCommonBorderStyle {
};


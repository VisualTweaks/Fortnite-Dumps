// BlueprintGeneratedClass CurieEntityStateBehavior_ElemInteraction_Water.CurieEntityStateBehavior_ElemInteraction_Water_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCurieEntityStateBehavior_ElemInteraction_Water_C : UFortCurieEntityStateBehavior {
};


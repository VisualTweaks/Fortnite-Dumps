// WidgetBlueprintGeneratedClass AthenaDirectAcquisitionOffer_SalesTextBanner.AthenaDirectAcquisitionOffer_SalesTextBanner_C
// Size: 0x279 (Inherited: 0x260)
struct UAthenaDirectAcquisitionOffer_SalesTextBanner_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UCommonBorder* BorderViolator-PercentOff; // 0x268(0x08)
	struct UCommonTextBlock* CTextBlockPercentOff; // 0x270(0x08)
	bool PointBorderLeft; // 0x278(0x01)

	void Set Sales Text(struct FText Sales Text); // Function AthenaDirectAcquisitionOffer_SalesTextBanner.AthenaDirectAcquisitionOffer_SalesTextBanner_C.Set Sales Text // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Construct(); // Function AthenaDirectAcquisitionOffer_SalesTextBanner.AthenaDirectAcquisitionOffer_SalesTextBanner_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void PreConstruct(bool IsDesignTime); // Function AthenaDirectAcquisitionOffer_SalesTextBanner.AthenaDirectAcquisitionOffer_SalesTextBanner_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_AthenaDirectAcquisitionOffer_SalesTextBanner(int32_t EntryPoint); // Function AthenaDirectAcquisitionOffer_SalesTextBanner.AthenaDirectAcquisitionOffer_SalesTextBanner_C.ExecuteUbergraph_AthenaDirectAcquisitionOffer_SalesTextBanner // (Final|UbergraphFunction|HasDefaults) // @ game+0xd6d38c
};


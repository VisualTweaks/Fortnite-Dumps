// WidgetBlueprintGeneratedClass AthenaRichColorVariantPicker.AthenaRichColorVariantPicker_C
// Size: 0x350 (Inherited: 0x350)
struct UAthenaRichColorVariantPicker_C : UFortVariantRichColorPicker {
};


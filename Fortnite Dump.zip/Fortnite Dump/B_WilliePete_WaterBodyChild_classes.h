// BlueprintGeneratedClass B_WilliePete_WaterBodyChild.B_WilliePete_WaterBodyChild_C
// Size: 0x2e8 (Inherited: 0x2d8)
struct AB_WilliePete_WaterBodyChild_C : AFortWaterBodyActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d8(0x08)
	struct UArrowComponent* Debug; // 0x2e0(0x08)

	void ReceiveBeginPlay(); // Function B_WilliePete_WaterBodyChild.B_WilliePete_WaterBodyChild_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_B_WilliePete_WaterBodyChild(int32_t EntryPoint); // Function B_WilliePete_WaterBodyChild.B_WilliePete_WaterBodyChild_C.ExecuteUbergraph_B_WilliePete_WaterBodyChild // (Final|UbergraphFunction) // @ game+0xd6d38c
};


// BlueprintGeneratedClass ChallengeTile_EmptyButton.ChallengeTile_EmptyButton_C
// Size: 0x570 (Inherited: 0x570)
struct UChallengeTile_EmptyButton_C : UCommonButtonStyle {
};


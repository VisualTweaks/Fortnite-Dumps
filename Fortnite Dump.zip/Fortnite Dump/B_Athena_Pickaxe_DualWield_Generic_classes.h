// BlueprintGeneratedClass B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C
// Size: 0x181c (Inherited: 0x1790)
struct AB_Athena_Pickaxe_DualWield_Generic_C : AFortWeaponPickaxeDualWieldAthena {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1790(0x08)
	bool Equipped; // 0x1798(0x01)
	enum class EAttachmentRule IdleFX Location Rule; // 0x1799(0x01)
	enum class EAttachmentRule Idle FX Rotation Rule; // 0x179a(0x01)
	enum class EAttachmentRule Idle FX Scale Rule; // 0x179b(0x01)
	enum class EAttachmentRule SwingFX Location Rule; // 0x179c(0x01)
	enum class EAttachmentRule Swing FX Rotation Rule; // 0x179d(0x01)
	enum class EAttachmentRule Swing FX Scale Rule; // 0x179e(0x01)
	char pad_179F[0x1]; // 0x179f(0x01)
	struct UParticleSystemComponent* Alteration Ambient PS; // 0x17a0(0x08)
	struct UParticleSystem* MeleeHeavy_ParticleSystem; // 0x17a8(0x08)
	struct UParticleSystemComponent* MeleeHeavy_PSC; // 0x17b0(0x08)
	bool UseDestroyEffect; // 0x17b8(0x01)
	char pad_17B9[0x7]; // 0x17b9(0x07)
	struct UParticleSystem* WeaponDurabilityDestroyEffect; // 0x17c0(0x08)
	struct UParticleSystem* WeaponDurabilityDestroyEffectIcon; // 0x17c8(0x08)
	struct UParticleSystemComponent* Offhand Alteration Ambient PS; // 0x17d0(0x08)
	bool bEquipPendingInstigator; // 0x17d8(0x01)
	char pad_17D9[0x3]; // 0x17d9(0x03)
	struct FName Offhand Socket Name; // 0x17dc(0x08)
	char pad_17E4[0x4]; // 0x17e4(0x04)
	struct UAnimMontage* MontageReference; // 0x17e8(0x08)
	bool UseTimeofDayControl; // 0x17f0(0x01)
	char pad_17F1[0x7]; // 0x17f1(0x07)
	struct UFXSystemComponent* Impact FX; // 0x17f8(0x08)
	bool Swing Right?; // 0x1800(0x01)
	char pad_1801[0x3]; // 0x1801(0x03)
	struct FRotator Left Swing Rotation; // 0x1804(0x0c)
	struct FRotator Right Swing Rotation; // 0x1810(0x0c)

	void Binding Time of Day Control(bool F)); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.Binding Time of Day Control // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SetWpnRarity(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.SetWpnRarity // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Unbind Dual Melee Swing Events(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.Unbind Dual Melee Swing Events // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Bind Dual Melee Swing Events(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.Bind Dual Melee Swing Events // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Set Active Alteration Idle Particles(bool Active, bool Reset); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.Set Active Alteration Idle Particles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void UserConstructionScript(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnStatChanged_9F72D14C4573F491E38302B51F08A0B8(struct FName StatName, int32_t StatValue); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.OnStatChanged_9F72D14C4573F491E38302B51F08A0B8 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnLoaded_F1C7B8E24518F4F2DE2C8DBABB95E06D(struct UObject* Loaded); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.OnLoaded_F1C7B8E24518F4F2DE2C8DBABB95E06D // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnPlayWeaponFireFX(bool bPersistentFire, bool bSecondaryFire); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.OnPlayWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void PlayRClickImpacts(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.PlayRClickImpacts // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnEquippedWeaponDestory(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.OnEquippedWeaponDestory // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnWeaponAttached(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnInitCosmeticAlterations(struct FFortCosmeticModification CosmeticMod); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.OnInitCosmeticAlterations // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnWeaponVisibilityChanged(bool bVisible, bool bSetForLocalControllerOnly); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.OnWeaponVisibilityChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnWeaponDetached(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.OnWeaponDetached // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnInitWeaponCosmetics(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.OnInitWeaponCosmetics // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void Swing Left End(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.Swing Left End // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Swing Right End(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.Swing Right End // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnInstigatorSet(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.OnInstigatorSet // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void K2_OnUnEquip(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void SwingRight_Common(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.SwingRight_Common // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SwingLeft_Common(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.SwingLeft_Common // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Swing Left(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.Swing Left // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Swing Right(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.Swing Right // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Swing Left 2(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.Swing Left 2 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Swing Right 2(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.Swing Right 2 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Anim Trails Notify(bool bActive); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.Anim Trails Notify // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Anim Trails Disable(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.Anim Trails Disable // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnPlayImpactFX(struct FHitResult& HitResult, enum class EPhysicalSurface ImpactPhysicalSurface, struct UFXSystemComponent* SpawnedPSC); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.OnPlayImpactFX // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void TODCheck(enum class EFortDayPhase CurrentDayPhase, enum class EFortDayPhase PreviousDayPhase, bool bAtCreation); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.TODCheck // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void HandleKillWatch(); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.HandleKillWatch // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void UpdateBasedOnKills(int32_t Watched Kills); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.UpdateBasedOnKills // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_B_Athena_Pickaxe_DualWield_Generic(int32_t EntryPoint); // Function B_Athena_Pickaxe_DualWield_Generic.B_Athena_Pickaxe_DualWield_Generic_C.ExecuteUbergraph_B_Athena_Pickaxe_DualWield_Generic // (Final|UbergraphFunction|HasDefaults) // @ game+0xd6d38c
};


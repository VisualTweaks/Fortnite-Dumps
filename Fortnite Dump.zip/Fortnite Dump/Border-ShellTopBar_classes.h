// BlueprintGeneratedClass Border-ShellTopBar.Border-ShellTopBar_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-ShellTopBar_C : UCommonBorderStyle {
};


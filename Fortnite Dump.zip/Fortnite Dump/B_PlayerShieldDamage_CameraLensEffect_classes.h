// BlueprintGeneratedClass B_PlayerShieldDamage_CameraLensEffect.B_PlayerShieldDamage_CameraLensEffect_C
// Size: 0x2f0 (Inherited: 0x2e8)
struct AB_PlayerShieldDamage_CameraLensEffect_C : AB_PlayerHealthDamage_CameraLensEffect_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e8(0x08)

	void PassParticle_Parameter_Shield(float NewParam); // Function B_PlayerShieldDamage_CameraLensEffect.B_PlayerShieldDamage_CameraLensEffect_C.PassParticle_Parameter_Shield // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_B_PlayerShieldDamage_CameraLensEffect(int32_t EntryPoint); // Function B_PlayerShieldDamage_CameraLensEffect.B_PlayerShieldDamage_CameraLensEffect_C.ExecuteUbergraph_B_PlayerShieldDamage_CameraLensEffect // (Final|UbergraphFunction) // @ game+0xd6d38c
};


// BlueprintGeneratedClass CurieEntityStateBehavior_Drying.CurieEntityStateBehavior_Drying_C
// Size: 0xe8 (Inherited: 0xe8)
struct UCurieEntityStateBehavior_Drying_C : UFortCurieEntityStateBehavior_Drying {
};


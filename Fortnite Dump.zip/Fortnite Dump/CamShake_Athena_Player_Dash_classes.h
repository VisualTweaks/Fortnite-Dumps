// BlueprintGeneratedClass CamShake_Athena_Player_Dash.CamShake_Athena_Player_Dash_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UCamShake_Athena_Player_Dash_C : UMatineeCameraShake {
};


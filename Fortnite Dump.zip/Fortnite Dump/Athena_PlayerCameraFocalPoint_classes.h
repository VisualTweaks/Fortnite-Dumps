// BlueprintGeneratedClass Athena_PlayerCameraFocalPoint.Athena_PlayerCameraFocalPoint_C
// Size: 0xde0 (Inherited: 0xde0)
struct UAthena_PlayerCameraFocalPoint_C : UFortCameraMode_FocalPoint {
};


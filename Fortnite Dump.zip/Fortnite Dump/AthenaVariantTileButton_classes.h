// WidgetBlueprintGeneratedClass AthenaVariantTileButton.AthenaVariantTileButton_C
// Size: 0xcb8 (Inherited: 0xca0)
struct UAthenaVariantTileButton_C : UFortVariantTileButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xca0(0x08)
	struct UWidgetAnimation* WarningPulse; // 0xca8(0x08)
	struct UImage* Image_Conflict; // 0xcb0(0x08)

	void OnListItemObjectSet(struct UObject* ListItemObject); // Function AthenaVariantTileButton.AthenaVariantTileButton_C.OnListItemObjectSet // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_AthenaVariantTileButton(int32_t EntryPoint); // Function AthenaVariantTileButton.AthenaVariantTileButton_C.ExecuteUbergraph_AthenaVariantTileButton // (Final|UbergraphFunction) // @ game+0xd6d38c
};


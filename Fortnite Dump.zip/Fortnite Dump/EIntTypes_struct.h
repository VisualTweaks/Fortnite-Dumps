// UserDefinedEnum EIntTypes.EIntTypes
enum class EIntTypes : uint8 {
	NewEnumerator4 = 0,
	NewEnumerator5 = 1,
	NewEnumerator6 = 2,
	NewEnumerator7 = 3,
	EIntTypes_MAX = 4
};


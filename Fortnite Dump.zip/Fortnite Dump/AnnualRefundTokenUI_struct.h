// Enum AnnualRefundTokenUI.EPurchaseReturnStep
enum class EPurchaseReturnStep : uint8 {
	ItemSelection = 0,
	ReasonSelection = 1,
	FinalSubmission = 2,
	EPurchaseReturnStep_MAX = 3
};


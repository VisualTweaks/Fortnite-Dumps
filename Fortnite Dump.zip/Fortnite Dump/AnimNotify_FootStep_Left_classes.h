// BlueprintGeneratedClass AnimNotify_FootStep_Left.AnimNotify_FootStep_Left_C
// Size: 0x3c (Inherited: 0x3c)
struct UAnimNotify_FootStep_Left_C : UAnimNotify_FootStep_C {
};


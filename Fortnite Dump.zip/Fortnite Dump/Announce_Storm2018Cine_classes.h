// BlueprintGeneratedClass Announce_Storm2018Cine.Announce_Storm2018Cine_C
// Size: 0x2c8 (Inherited: 0x2c8)
struct AAnnounce_Storm2018Cine_C : AAnnounce_EventCine_C {
};


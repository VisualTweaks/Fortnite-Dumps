// BlueprintGeneratedClass CameraShake_ZipLineAttach.CameraShake_ZipLineAttach_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UCameraShake_ZipLineAttach_C : UMatineeCameraShake {
};


// BlueprintGeneratedClass EditableTextUtilities.EditableTextUtilities_C
// Size: 0x28 (Inherited: 0x28)
struct UEditableTextUtilities_C : UBlueprintFunctionLibrary {

	void CheckIfNeedsTrimming(struct FText Text, int32_t Limit, struct UObject* __WorldContext, struct FText& TrimmedText, bool& WasTrimmed); // Function EditableTextUtilities.EditableTextUtilities_C.CheckIfNeedsTrimming // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void LimitTextLength(struct UWidget* EditableTextWidget, int32_t Length, struct UObject* __WorldContext, bool& WasTrimmed); // Function EditableTextUtilities.EditableTextUtilities_C.LimitTextLength // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
};


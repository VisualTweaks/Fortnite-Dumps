// BlueprintGeneratedClass B_Prj_Ostrich_Rocket.B_Prj_Ostrich_Rocket_C
// Size: 0x940 (Inherited: 0x880)
struct AB_Prj_Ostrich_Rocket_C : AFortProjectile_DrunkHoming {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x880(0x08)
	struct UParticleSystemComponent*  RocketTrailPS; // 0x888(0x08)
	struct UStaticMeshComponent* SM_OstrichRocket; // 0x890(0x08)
	struct UAudioComponent* Rocket_AudioComponent; // 0x898(0x08)
	struct UParticleSystemComponent* Ribbon_Trail_PSC; // 0x8a0(0x08)
	struct UParticleSystem* Ribbon_Trail_PS; // 0x8a8(0x08)
	struct UParticleSystem* Explosion_Generic_PS; // 0x8b0(0x08)
	struct UParticleSystemComponent* Explosion_Generic_PSC; // 0x8b8(0x08)
	struct USoundBase* Rocket_Projectile_Explosion_Sound; // 0x8c0(0x08)
	struct FVector StopLocation; // 0x8c8(0x0c)
	char pad_8D4[0x4]; // 0x8d4(0x04)
	struct UParticleSystem* Explosion_Flesh_Damage_PS; // 0x8d8(0x08)
	struct FRotator StopRotZ; // 0x8e0(0x0c)
	char pad_8EC[0x4]; // 0x8ec(0x04)
	struct UParticleSystemComponent* Explosion_Flesh_Damage_PSC; // 0x8f0(0x08)
	struct USoundBase* Rocket_Projectile_Explosion_Water_Sound; // 0x8f8(0x08)
	float Tick Delta; // 0x900(0x04)
	float RocketSpinRate; // 0x904(0x04)
	float Explosion Impact Offset; // 0x908(0x04)
	struct FRotator RocketSpin; // 0x90c(0x0c)
	bool TimerMaxReached?; // 0x918(0x01)
	char pad_919[0x3]; // 0x919(0x03)
	struct FVector DecalLocation; // 0x91c(0x0c)
	enum class EPhysicalSurface SurfaceType; // 0x928(0x01)
	char pad_929[0x3]; // 0x929(0x03)
	struct FGameplayTag FeedbackCue; // 0x92c(0x08)
	char pad_934[0x4]; // 0x934(0x04)
	struct UParticleSystem* Explosion Water; // 0x938(0x08)

	void UserConstructionScript(); // Function B_Prj_Ostrich_Rocket.B_Prj_Ostrich_Rocket_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnStop(struct FHitResult& Hit); // Function B_Prj_Ostrich_Rocket.B_Prj_Ostrich_Rocket_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveBeginPlay(); // Function B_Prj_Ostrich_Rocket.B_Prj_Ostrich_Rocket_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void FuseTimerMax(); // Function B_Prj_Ostrich_Rocket.B_Prj_Ostrich_Rocket_C.FuseTimerMax // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnExploded(struct TArray<struct AActor*>& HitActors, struct TArray<struct FHitResult>& HitResults); // Function B_Prj_Ostrich_Rocket.B_Prj_Ostrich_Rocket_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveTick(float DeltaSeconds); // Function B_Prj_Ostrich_Rocket.B_Prj_Ostrich_Rocket_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveDestroyed(); // Function B_Prj_Ostrich_Rocket.B_Prj_Ostrich_Rocket_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnTouched(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FHitResult& HitResult, bool bIsOverlap); // Function B_Prj_Ostrich_Rocket.B_Prj_Ostrich_Rocket_C.OnTouched // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void OnHomingPassedTarget(); // Function B_Prj_Ostrich_Rocket.B_Prj_Ostrich_Rocket_C.OnHomingPassedTarget // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_B_Prj_Ostrich_Rocket(int32_t EntryPoint); // Function B_Prj_Ostrich_Rocket.B_Prj_Ostrich_Rocket_C.ExecuteUbergraph_B_Prj_Ostrich_Rocket // (Final|UbergraphFunction|HasDefaults) // @ game+0xd6d38c
};


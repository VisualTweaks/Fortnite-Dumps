// BlueprintGeneratedClass Athena_ButtonStyle_BlueMenuButton_Settings.Athena_ButtonStyle_BlueMenuButton_Settings_C
// Size: 0x570 (Inherited: 0x570)
struct UAthena_ButtonStyle_BlueMenuButton_Settings_C : UCommonButtonStyle {
};


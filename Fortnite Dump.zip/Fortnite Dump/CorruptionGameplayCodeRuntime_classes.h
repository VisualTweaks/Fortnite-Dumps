// Class CorruptionGameplayCodeRuntime.CorruptionCoverageMap
// Size: 0x70 (Inherited: 0x28)
struct UCorruptionCoverageMap : UObject {
	char pad_28[0x48]; // 0x28(0x48)

	bool UpdateCorruptionCoverageMap(struct UObject* WorldContextObject, struct UTextureRenderTarget2D* CorruptionRenderTarget, struct FVector& InTopLeftWorldCoordinate, struct FVector& InBottomRightWorldCoordinate, float CoverageThreshold, float DebugDrawDuration); // Function CorruptionGameplayCodeRuntime.CorruptionCoverageMap.UpdateCorruptionCoverageMap // (Final|Native|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x282e1ac
	bool IsLocationCorrupted(struct FVector& Location, float Padding); // Function CorruptionGameplayCodeRuntime.CorruptionCoverageMap.IsLocationCorrupted // (Final|Native|Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3fa1b78
};

// Class CorruptionGameplayCodeRuntime.FortCorruptionSequenceData
// Size: 0x50 (Inherited: 0x30)
struct UFortCorruptionSequenceData : UPrimaryDataAsset {
	struct TArray<struct FCorruptionCalendarEventData> CorruptionStartEvents; // 0x30(0x10)
	struct TArray<struct FCorruptionPauseEvent> CorruptionPauseEvents; // 0x40(0x10)
};

// Class CorruptionGameplayCodeRuntime.CubeMovementStaticPath
// Size: 0x4b0 (Inherited: 0x480)
struct ACubeMovementStaticPath : AScriptedObjectMovement_StaticPath {
	float GenerationZTraceHeight; // 0x478(0x04)
	float CubeSpacingFactor; // 0x47c(0x04)
	float CubeAngleLimitDegrees; // 0x480(0x04)
	struct UFortCorruptionSequenceData* CorruptionSequence; // 0x488(0x08)
	char pad_494[0x4]; // 0x494(0x04)
	struct TArray<struct FTravelerStepCorruptionOverrideData> TravelerCorruptionStepPercentOverrides; // 0x498(0x10)
	char pad_4A8[0x8]; // 0x4a8(0x08)

	void EditorGetCorruptionGenerationData(struct FCubeMovement_CorruptionGenerationData& OutData); // Function CorruptionGameplayCodeRuntime.CubeMovementStaticPath.EditorGetCorruptionGenerationData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3fa1718
	void ClearAllGeneratedSplinesAndLockedData(); // Function CorruptionGameplayCodeRuntime.CubeMovementStaticPath.ClearAllGeneratedSplinesAndLockedData // (Final|Native|Protected) // @ game+0x3fa1598
};

// Class CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort
// Size: 0x450 (Inherited: 0x3d8)
struct AFortAthenaMutator_WarEffort : AFortAthenaMutator_GameModeBase {
	struct TArray<struct FWarEffortMutatorChoiceData> WeaponChoices; // 0x3d8(0x10)
	struct TArray<struct FPrimaryAssetId> PreloadedWarEffortWeapons; // 0x3e8(0x10)
	char pad_3F8[0x58]; // 0x3f8(0x58)

	void SetItemFundedPercent(struct FGameplayTag ItemFundingTag, float FundingPercent); // Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedPercent // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa20b8
	void SetItemFundedAmount(struct FGameplayTag ItemFundingTag, int64_t CurrentFundingAmount, int64_t TargetFundingAmount); // Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedAmount // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa1f78
	void OnRep_PreloadedWarEffortWeapons(); // Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.OnRep_PreloadedWarEffortWeapons // (Final|Native|Protected) // @ game+0x3fa1f64
};

// Class CorruptionGameplayCodeRuntime.WarEffortFundingLibrary
// Size: 0x28 (Inherited: 0x28)
struct UWarEffortFundingLibrary : UBlueprintFunctionLibrary {

	struct FString WriteTextToBuffer(struct FText& Text); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.WriteTextToBuffer // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3fa21a8
	bool IsOption2ChoiceWinner(struct FWarEffortFundingMetadata& MetaData, int32_t ChoiceIndex); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsOption2ChoiceWinner // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3fa1e08
	bool IsOption1ChoiceWinner(struct FWarEffortFundingMetadata& MetaData, int32_t ChoiceIndex); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsOption1ChoiceWinner // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3fa1cac
	bool IsIndexFunded(struct FWarEffortFundingMetadata& MetaData, int32_t Index, enum class EWarEffortFundingStationType StationType); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsIndexFunded // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3fa19cc
	float GetIndexFundedPercent(struct FWarEffortFundingMetadata& MetaData, int32_t Index, enum class EWarEffortFundingStationType StationType); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.GetIndexFundedPercent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3fa1840
	bool DoesChoiceHaveWinner(struct FWarEffortFundingMetadata& MetaData, int32_t ChoiceIndex); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.DoesChoiceHaveWinner // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3fa15ac
	int32_t AdjustDonation(int32_t DonationAmount, enum class EWarEffortFundingStationType StationType); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.AdjustDonation // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3fa145c
};


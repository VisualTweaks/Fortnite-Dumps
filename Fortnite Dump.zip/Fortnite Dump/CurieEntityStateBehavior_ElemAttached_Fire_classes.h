// BlueprintGeneratedClass CurieEntityStateBehavior_ElemAttached_Fire.CurieEntityStateBehavior_ElemAttached_Fire_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCurieEntityStateBehavior_ElemAttached_Fire_C : UFortCurieEntityStateBehavior {
};


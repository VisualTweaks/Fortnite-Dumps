// BlueprintGeneratedClass BattlePassPageUnlockNotification.BattlePassPageUnlockNotification_C
// Size: 0x100 (Inherited: 0x100)
struct UBattlePassPageUnlockNotification_C : UFortUIBattlePassPageUnlockNotification {
};


// BlueprintGeneratedClass Border-ItemInfoHeader.Border-ItemInfoHeader_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-ItemInfoHeader_C : UCommonBorderStyle {
};


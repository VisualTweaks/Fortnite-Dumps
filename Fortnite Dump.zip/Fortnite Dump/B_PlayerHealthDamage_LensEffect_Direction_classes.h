// BlueprintGeneratedClass B_PlayerHealthDamage_LensEffect_Direction.B_PlayerHealthDamage_LensEffect_Direction_C
// Size: 0x310 (Inherited: 0x310)
struct AB_PlayerHealthDamage_LensEffect_Direction_C : AFortEmitterCameraLensEffectDirectional {
};


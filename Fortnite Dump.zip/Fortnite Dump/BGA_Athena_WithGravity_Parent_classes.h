// BlueprintGeneratedClass BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C
// Size: 0x9de (Inherited: 0x8b8)
struct ABGA_Athena_WithGravity_Parent_C : ABuildingGameplayActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x8b8(0x08)
	struct UFortWaterInteractionComponent* FortWaterInteraction; // 0x8c0(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x8c8(0x08)
	struct UProjectileMovementComponent* ProjectileMovement; // 0x8d0(0x08)
	bool ResumeGravSimOnBegin; // 0x8d8(0x01)
	bool bResumeSimulation; // 0x8d9(0x01)
	char pad_8DA[0x2]; // 0x8da(0x02)
	struct FHitResult NullHit; // 0x8dc(0x88)
	struct FVector GravImpact_Loc; // 0x964(0x0c)
	struct FVector GravHitNormal; // 0x970(0x0c)
	float GravMaxSlope; // 0x97c(0x04)
	bool CheckForBounce; // 0x980(0x01)
	char pad_981[0x3]; // 0x981(0x03)
	float ForcedBounceExtraZ; // 0x984(0x04)
	int32_t ForcedBounceCurrentCount; // 0x988(0x04)
	float ForcedBounceMult; // 0x98c(0x04)
	struct TArray<struct AActor*> GravFoundBuildingOnDied; // 0x990(0x10)
	bool RepCollision; // 0x9a0(0x01)
	char pad_9A1[0x7]; // 0x9a1(0x07)
	struct UObject* AdditionalBounceObject; // 0x9a8(0x08)
	int32_t ForcedBounceMaxCount; // 0x9b0(0x04)
	bool ForceBounce; // 0x9b4(0x01)
	bool CountNonForceBounces; // 0x9b5(0x01)
	char pad_9B6[0x2]; // 0x9b6(0x02)
	float BounceExtraZ; // 0x9b8(0x04)
	float BounceMult; // 0x9bc(0x04)
	bool ShouldAttach; // 0x9c0(0x01)
	char pad_9C1[0x7]; // 0x9c1(0x07)
	struct TArray<struct AActor*> ActorsToNotAttachTo; // 0x9c8(0x10)
	bool DontAttachToOthersOfThisClass; // 0x9d8(0x01)
	bool DebugText; // 0x9d9(0x01)
	bool ShouldNotReattach; // 0x9da(0x01)
	bool BlockStoppingSim; // 0x9db(0x01)
	bool DeactivatePawnAndVehicleCollisionOnStop; // 0x9dc(0x01)
	bool AllowReattachmentToActors; // 0x9dd(0x01)

	void Init(struct FVector GravHitNormal); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.Init // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnAttach(struct AActor* AttachedActor); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.OnAttach // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void RestartSimulation(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.RestartSimulation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void AttachToBindedActor(struct UPrimitiveComponent* AttachComp); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.AttachToBindedActor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void BounceBGA(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.BounceBGA // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void CheckForSameClassToBounce(struct AActor* Hit, bool& HitSameClass); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.CheckForSameClassToBounce // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnRep_RepCollision(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.OnRep_RepCollision // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ForceBounceBGA(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.ForceBounceBGA // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnRep_bResumeSimulation(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.OnRep_bResumeSimulation // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void BaseDestroyed(struct AActor* DestroyedActor); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.BaseDestroyed // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void HandleBinding(struct AActor* Actor, struct UPrimitiveComponent* HitComp); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.HandleBinding // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.ReceiveHit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void BaseDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.BaseDied // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void StopSim(struct FHitResult Hit); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.StopSim // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveBeginPlay(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void Impulse(float DelayBeforeImpulse, float DelayBeforeCollision, struct FVector ImpulseOrigin, struct FVector ImpulseAmount, bool SetCollisionAfterImpulse); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.Impulse // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void PlayHitFX(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.PlayHitFX // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SpawnFXSounds(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.SpawnFXSounds // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void AttachedWasDestroyed(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.AttachedWasDestroyed // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SlidingDoorOpened(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.SlidingDoorOpened // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_BGA_Athena_WithGravity_Parent(int32_t EntryPoint); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.ExecuteUbergraph_BGA_Athena_WithGravity_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0xd6d38c
};


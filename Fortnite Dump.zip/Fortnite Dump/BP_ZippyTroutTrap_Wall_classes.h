// BlueprintGeneratedClass BP_ZippyTroutTrap_Wall.BP_ZippyTroutTrap_Wall_C
// Size: 0xee9 (Inherited: 0xee9)
struct ABP_ZippyTroutTrap_Wall_C : ABP_ZippyTroutTrap_Floor_C {
};


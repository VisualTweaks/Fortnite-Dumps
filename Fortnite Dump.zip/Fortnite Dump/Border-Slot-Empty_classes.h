// BlueprintGeneratedClass Border-Slot-Empty.Border-Slot-Empty_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-Slot-Empty_C : UCommonBorderStyle {
};


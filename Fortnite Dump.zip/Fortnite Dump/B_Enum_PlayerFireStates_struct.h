// UserDefinedEnum B_Enum_PlayerFireStates.B_Enum_PlayerFireStates
enum class B_Enum_PlayerFireStates : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	B_Enum_MAX = 3
};


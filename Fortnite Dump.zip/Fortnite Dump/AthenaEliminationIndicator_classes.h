// WidgetBlueprintGeneratedClass AthenaEliminationIndicator.AthenaEliminationIndicator_C
// Size: 0x550 (Inherited: 0x528)
struct UAthenaEliminationIndicator_C : UAthenaEliminationIndicator {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x528(0x08)
	struct UWidgetAnimation* Outro; // 0x530(0x08)
	struct UWidgetAnimation* Intro; // 0x538(0x08)
	struct UImage* Arrow; // 0x540(0x08)
	struct UImage* Image_Diamondpulse; // 0x548(0x08)

	void Construct(); // Function AthenaEliminationIndicator.AthenaEliminationIndicator_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_AthenaEliminationIndicator(int32_t EntryPoint); // Function AthenaEliminationIndicator.AthenaEliminationIndicator_C.ExecuteUbergraph_AthenaEliminationIndicator // (Final|UbergraphFunction) // @ game+0xd6d38c
};


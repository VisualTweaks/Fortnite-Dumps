// BlueprintGeneratedClass ButtonStyle_VoiceHeader.ButtonStyle_VoiceHeader_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle_VoiceHeader_C : UCommonButtonStyle {
};


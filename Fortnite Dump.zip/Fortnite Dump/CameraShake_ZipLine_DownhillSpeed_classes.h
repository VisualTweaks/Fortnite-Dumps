// BlueprintGeneratedClass CameraShake_ZipLine_DownhillSpeed.CameraShake_ZipLine_DownhillSpeed_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UCameraShake_ZipLine_DownhillSpeed_C : UMatineeCameraShake {
};


// BlueprintGeneratedClass CMSLobbyDirector.CMSLobbyDirector_C
// Size: 0x2f0 (Inherited: 0x2e8)
struct ACMSLobbyDirector_C : ADynamicBackgroundDirector {
	struct USceneComponent* DefaultSceneRoot; // 0x2e8(0x08)
};


// BlueprintGeneratedClass Border-PowerToast.Border-PowerToast_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-PowerToast_C : UCommonBorderStyle {
};


// BlueprintGeneratedClass B_AthenaAlwaysLoadedContentHack.B_AthenaAlwaysLoadedContentHack_C
// Size: 0x248 (Inherited: 0x220)
struct AB_AthenaAlwaysLoadedContentHack_C : AActor {
	struct USceneComponent* DefaultSceneRoot; // 0x220(0x08)
	struct TArray<struct UObject*> HardObjectList; // 0x228(0x10)
	struct TArray<struct UObject*> HardClassList; // 0x238(0x10)
};


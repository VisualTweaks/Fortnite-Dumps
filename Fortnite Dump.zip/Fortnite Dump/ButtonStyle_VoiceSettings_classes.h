// BlueprintGeneratedClass ButtonStyle_VoiceSettings.ButtonStyle_VoiceSettings_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle_VoiceSettings_C : UCommonButtonStyle {
};


// BlueprintGeneratedClass BP_CameraLens_CrackExit.BP_CameraLens_CrackExit_C
// Size: 0x2e8 (Inherited: 0x2e0)
struct ABP_CameraLens_CrackExit_C : AEmitterCameraLensEffectBase {
	struct UParticleSystemComponent* Portal; // 0x2e0(0x08)
};


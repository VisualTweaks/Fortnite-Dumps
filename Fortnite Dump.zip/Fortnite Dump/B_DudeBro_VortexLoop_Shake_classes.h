// BlueprintGeneratedClass B_DudeBro_VortexLoop_Shake.B_DudeBro_VortexLoop_Shake_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UB_DudeBro_VortexLoop_Shake_C : UMatineeCameraShake {
};


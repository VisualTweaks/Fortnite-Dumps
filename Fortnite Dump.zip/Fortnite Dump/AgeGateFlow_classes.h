// WidgetBlueprintGeneratedClass AgeGateFlow.AgeGateFlow_C
// Size: 0x578 (Inherited: 0x558)
struct UAgeGateFlow_C : UFortAgeGateFlow {
	struct UCommonActionWidget* CommonActionWidget_795; // 0x558(0x08)
	struct UImage* Image; // 0x560(0x08)
	struct UImage* Image_2; // 0x568(0x08)
	struct UImage* Image_256; // 0x570(0x08)
};


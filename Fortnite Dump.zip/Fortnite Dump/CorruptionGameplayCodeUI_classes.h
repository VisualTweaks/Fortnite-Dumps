// Class CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget
// Size: 0x2e0 (Inherited: 0x2d8)
struct UFortPowerupReticleExtensionWidget : UFortWeaponReticleExtensionWidgetBase {
	enum class EPowerupHeatState LastPowerupHeatState; // 0x2d8(0x01)
	char pad_2D9[0x7]; // 0x2d9(0x07)

	float GetOverheatingMaxValue(); // Function CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget.GetOverheatingMaxValue // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x3fa240c
	float GetCurrentOverheatValue(); // Function CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget.GetCurrentOverheatValue // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x3fa23e4
	float GetCurrentOverheatPercent(); // Function CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget.GetCurrentOverheatPercent // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x3fa23bc
};


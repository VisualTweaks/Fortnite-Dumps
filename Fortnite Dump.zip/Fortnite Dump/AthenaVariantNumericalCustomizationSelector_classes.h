// WidgetBlueprintGeneratedClass AthenaVariantNumericalCustomizationSelector.AthenaVariantNumericalCustomizationSelector_C
// Size: 0x350 (Inherited: 0x350)
struct UAthenaVariantNumericalCustomizationSelector_C : UFortVariantNumericalPicker {
};


// BlueprintGeneratedClass DefaultBuildingTool.DefaultBuildingTool_C
// Size: 0x15b0 (Inherited: 0x15b0)
struct ADefaultBuildingTool_C : AFortWeap_BuildingTool {
};


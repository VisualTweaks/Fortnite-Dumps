// BlueprintGeneratedClass BulletWhipTrackerComponent_AR.BulletWhipTrackerComponent_AR_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBulletWhipTrackerComponent_AR_C : UBulletWhipTrackerComponentBase {
};


// BlueprintGeneratedClass CurieEntityStateBehavior_ElemAttached_Ice.CurieEntityStateBehavior_ElemAttached_Ice_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCurieEntityStateBehavior_ElemAttached_Ice_C : UFortCurieEntityStateBehavior {
};


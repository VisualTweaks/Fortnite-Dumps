// BlueprintGeneratedClass DefaultEditingTool.DefaultEditingTool_C
// Size: 0x14a0 (Inherited: 0x14a0)
struct ADefaultEditingTool_C : AFortWeap_EditingTool {
};


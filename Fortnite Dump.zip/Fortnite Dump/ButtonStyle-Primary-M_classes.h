// BlueprintGeneratedClass ButtonStyle-Primary-M.ButtonStyle-Primary-M_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Primary-M_C : UCommonButtonStyle {
};


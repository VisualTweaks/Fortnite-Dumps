// BlueprintGeneratedClass BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C
// Size: 0xb60 (Inherited: 0xaa8)
struct ABP_Athena_Environmental_ZipLine_Spline_C : AFortAthenaSplineZipline {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xaa8(0x08)
	struct UStaticMesh* SplineStaticMesh; // 0xab0(0x08)
	float TangentSmoothStrength; // 0xab8(0x04)
	bool AutoSmoothTangents; // 0xabc(0x01)
	enum class ESplineMeshAxis ForwardMeshAxis; // 0xabd(0x01)
	char pad_ABE[0x2]; // 0xabe(0x02)
	struct FVector MotorOffset; // 0xac0(0x0c)
	char pad_ACC[0x4]; // 0xacc(0x04)
	struct AActor* PoleA; // 0xad0(0x08)
	struct AActor* PoleB; // 0xad8(0x08)
	struct FVector PoleASocketLocation; // 0xae0(0x0c)
	struct FVector PoleBSocketLocation; // 0xaec(0x0c)
	int32_t LowerPointID; // 0xaf8(0x04)
	int32_t HigherPointID; // 0xafc(0x04)
	struct FVector HigherEndLocation; // 0xb00(0x0c)
	struct FVector LowerEndLocation; // 0xb0c(0x0c)
	float AutoLinearFactorLow; // 0xb18(0x04)
	float AutoLinearFactorHigh; // 0xb1c(0x04)
	float AutoSplineTangentLengthCoef; // 0xb20(0x04)
	float AutoSplineTangentHorizCoef; // 0xb24(0x04)
	float AutoSplineTangentVertCoef; // 0xb28(0x04)
	bool Auto Set Spline Ends; // 0xb2c(0x01)
	bool Auto Set Spline Mids; // 0xb2d(0x01)
	char pad_B2E[0x2]; // 0xb2e(0x02)
	struct TArray<struct UMaterialInstanceDynamic*> SplineMaterials; // 0xb30(0x10)
	struct FGameplayTagContainer BlockInteractTags; // 0xb40(0x20)

	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xd6d38c
	void GetAutoHorizAndVertVectors(struct FVector highVector, struct FVector LowVector, struct FVector& VertVec, struct FVector& HorizVec); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.GetAutoHorizAndVertVectors // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Calc Auto Location At Alpha(float InAlpha, bool DrawDebug, struct FVector& PointLocation); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.Calc Auto Location At Alpha // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SetSplinePositionAndTangent(bool SetPosition, bool SetTangent, int32_t ID); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.SetSplinePositionAndTangent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void CalculatePositionOfPoles(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.CalculatePositionOfPoles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void AutoSmoothTanget(struct FVector Tangent, struct FVector PointA, struct FVector PointB, struct FVector& SmoothedTangent); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.AutoSmoothTanget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xd6d38c
	void AddSplineMeshSegment(struct USplineMeshComponent*& SplineMeshSegment); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.AddSplineMeshSegment // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void UserConstructionScript(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveBeginPlay(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void PlayerAttachedToZipline(struct AFortPlayerPawn* PlayerPawn); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.PlayerAttachedToZipline // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void PlayerDetachedFromZipline(struct AFortPlayerPawn* PlayerPawn); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.PlayerDetachedFromZipline // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_BP_Athena_Environmental_ZipLine_Spline(int32_t EntryPoint); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.ExecuteUbergraph_BP_Athena_Environmental_ZipLine_Spline // (Final|UbergraphFunction) // @ game+0xd6d38c
};


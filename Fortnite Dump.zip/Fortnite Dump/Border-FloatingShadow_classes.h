// BlueprintGeneratedClass Border-FloatingShadow.Border-FloatingShadow_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-FloatingShadow_C : UCommonBorderStyle {
};


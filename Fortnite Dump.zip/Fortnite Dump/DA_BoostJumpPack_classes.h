// BlueprintGeneratedClass DA_BoostJumpPack.DA_BoostJumpPack_C
// Size: 0x1528 (Inherited: 0x14e0)
struct ADA_BoostJumpPack_C : AFortCustomizableAbilityDecoTool {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x14e0(0x08)
	struct FGameplayTagContainer ErrorReason; // 0x14e8(0x20)
	struct FGameplayTagContainer ErrorReasonGamepad; // 0x1508(0x20)

	void IsOnGround(bool& bOnGround); // Function DA_BoostJumpPack.DA_BoostJumpPack_C.IsOnGround // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xd6d38c
	void RaiseUsageError(struct FGameplayTagContainer& FailedReason); // Function DA_BoostJumpPack.DA_BoostJumpPack_C.RaiseUsageError // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void BPPressTrigger(struct AFortDecoHelper* FortDecoHelper); // Function DA_BoostJumpPack.DA_BoostJumpPack_C.BPPressTrigger // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_DA_BoostJumpPack(int32_t EntryPoint); // Function DA_BoostJumpPack.DA_BoostJumpPack_C.ExecuteUbergraph_DA_BoostJumpPack // (Final|UbergraphFunction|HasDefaults) // @ game+0xd6d38c
};


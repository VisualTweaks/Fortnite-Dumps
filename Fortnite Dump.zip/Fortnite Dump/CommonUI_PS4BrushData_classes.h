// BlueprintGeneratedClass CommonUI_PS4BrushData.CommonUI_PS4BrushData_C
// Size: 0xd0 (Inherited: 0xd0)
struct UCommonUI_PS4BrushData_C : UFortInputControllerData {
};


// BlueprintGeneratedClass ButtonStyle-Yellow-NewCTA.ButtonStyle-Yellow-NewCTA_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Yellow-NewCTA_C : UCommonButtonStyle {
};


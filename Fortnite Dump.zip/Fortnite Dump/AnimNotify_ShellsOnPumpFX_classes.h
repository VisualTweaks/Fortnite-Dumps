// BlueprintGeneratedClass AnimNotify_ShellsOnPumpFX.AnimNotify_ShellsOnPumpFX_C
// Size: 0x38 (Inherited: 0x38)
struct UAnimNotify_ShellsOnPumpFX_C : UAnimNotify {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_ShellsOnPumpFX.AnimNotify_ShellsOnPumpFX_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xd6d38c
};


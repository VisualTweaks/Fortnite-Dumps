// Class CRDWeblinkUI.WeblinkComponent
// Size: 0x108 (Inherited: 0xb0)
struct UWeblinkComponent : UActorComponent {
	struct UAthenaConfirmationWindow* ConfirmationWindowClass; // 0xb0(0x08)
	struct FMulticastInlineDelegate ConfirmationConfirmedDelegate; // 0xb8(0x10)
	struct FMulticastInlineDelegate ConfirmationDeclinedDelegate; // 0xc8(0x10)
	struct FText Title; // 0xd8(0x18)
	struct FText Description; // 0xf0(0x18)

	void DisplayConfirmation(); // Function CRDWeblinkUI.WeblinkComponent.DisplayConfirmation // (Final|Native|Public|BlueprintCallable) // @ game+0x4068f30
};


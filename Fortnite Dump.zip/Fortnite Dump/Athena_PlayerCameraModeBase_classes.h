// BlueprintGeneratedClass Athena_PlayerCameraModeBase.Athena_PlayerCameraModeBase_C
// Size: 0xde0 (Inherited: 0xde0)
struct UAthena_PlayerCameraModeBase_C : UFortCameraMode_ThirdPerson {
};


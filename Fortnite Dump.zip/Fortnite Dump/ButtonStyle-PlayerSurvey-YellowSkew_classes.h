// BlueprintGeneratedClass ButtonStyle-PlayerSurvey-YellowSkew.ButtonStyle-PlayerSurvey-YellowSkew_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-PlayerSurvey-YellowSkew_C : UCommonButtonStyle {
};


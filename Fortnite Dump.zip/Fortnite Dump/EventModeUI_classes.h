// Class EventModeUI.FocusButton
// Size: 0x3e0 (Inherited: 0x3d0)
struct UFocusButton : UBacchusActionButton {
	struct UPaperSprite* StartFocusingSprite; // 0x3d0(0x08)
	struct UPaperSprite* StopFocusingSprite; // 0x3d8(0x08)

	void HandleEventModeFocusingChanged(bool bIsEventModeFocusing); // Function EventModeUI.FocusButton.HandleEventModeFocusingChanged // (Final|Native|Private) // @ game+0x408e068
	void HandleCanUseEventModeFocusChanged(bool bCanUseEventModeFocus); // Function EventModeUI.FocusButton.HandleCanUseEventModeFocusChanged // (Final|Native|Private) // @ game+0x408df3c
};

// Class EventModeUI.FortEventModeEmotesWidget
// Size: 0x378 (Inherited: 0x2c8)
struct UFortEventModeEmotesWidget : UFortHUDElementWidget {
	struct TSoftObjectPtr<UFortMontageItemDefinitionBase> Emote1; // 0x2c8(0x28)
	struct TSoftObjectPtr<UFortMontageItemDefinitionBase> Emote2; // 0x2f0(0x28)
	struct TSoftObjectPtr<UFortMontageItemDefinitionBase> Emote3; // 0x318(0x28)
	struct TArray<struct TSoftObjectPtr<UFortMontageItemDefinitionBase>> RandomEmotes; // 0x340(0x10)
	char pad_350[0x8]; // 0x350(0x08)
	struct URichTextBlock* Text_Emote1; // 0x358(0x08)
	struct URichTextBlock* Text_Emote2; // 0x360(0x08)
	struct URichTextBlock* Text_Emote3; // 0x368(0x08)
	struct URichTextBlock* Text_EmoteRandom; // 0x370(0x08)

	void OnFocusStateChanged(bool bIsFocusing); // Function EventModeUI.FortEventModeEmotesWidget.OnFocusStateChanged // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnFocusAvailableChanged(bool bIsFocusAvailable); // Function EventModeUI.FortEventModeEmotesWidget.OnFocusAvailableChanged // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
};

// Class EventModeUI.FortMobileActionButtonBehavior_Focus
// Size: 0x100 (Inherited: 0xf8)
struct UFortMobileActionButtonBehavior_Focus : UFortMobileActionButtonBehavior {
	struct UPaperSprite* StopFocusingSprite; // 0xf8(0x08)

	void HandleEventModeFocusingChanged(bool bIsEventModeFocusing); // Function EventModeUI.FortMobileActionButtonBehavior_Focus.HandleEventModeFocusingChanged // (Final|Native|Private) // @ game+0x408e104
	void HandleCanUseEventModeFocusChanged(bool bCanUseEventModeFocus); // Function EventModeUI.FortMobileActionButtonBehavior_Focus.HandleCanUseEventModeFocusChanged // (Final|Native|Private) // @ game+0x408dfd0
};


// UserDefinedStruct DayPhaseFloats.DayPhaseFloats
// Size: 0x10 (Inherited: 0x00)
struct FDayPhaseFloats {
	float Morning_2_DA7D290F4DA80AC0D79B888F8B1E63AF; // 0x00(0x04)
	float Day_6_7AC9422D4E5DA1F7855ECF8DF66BAFB1; // 0x04(0x04)
	float Evening_7_A7E95DF64346D1824EB55E8083A4525F; // 0x08(0x04)
	float Night_8_BD65E285445A3ED05CA26694CF4E873E; // 0x0c(0x04)
};


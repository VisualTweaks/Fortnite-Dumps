// BlueprintGeneratedClass ButtonStyle_Skew_Tab.ButtonStyle_Skew_Tab_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle_Skew_Tab_C : UCommonButtonStyle {
};


// BlueprintGeneratedClass DefaultUIDataConfiguration.DefaultUIDataConfiguration_C
// Size: 0x3e98 (Inherited: 0x3e98)
struct UDefaultUIDataConfiguration_C : UFortUIDataConfiguration {
};


// UserDefinedStruct FCreativeEffectColorIndex.FCreativeEffectColorIndex
// Size: 0x07 (Inherited: 0x00)
struct FFCreativeEffectColorIndex {
	int32_t Index_2_D2D2DEB24E760961E0D6AB88DC603692; // 0x00(0x04)
	enum class ECreativeColorSetType SetType_5_3A2997D544A0618EC312FEAED95187B8; // 0x04(0x01)
	enum class E_Creative_Powerup_LocalVisibility VisibleToOwningPlayer_8_E546F2A4426B8AB99EE118A3125AC217; // 0x05(0x01)
	enum class E_Creative_Powerup_TeamRelationshipVisibility TeamRelationshipVisibility_11_3BB5265D4D611D2BB5799EB5A6E26AA7; // 0x06(0x01)
};


// BlueprintGeneratedClass Border-AthenaItemInfoHeader.Border-AthenaItemInfoHeader_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-AthenaItemInfoHeader_C : UCommonBorderStyle {
};


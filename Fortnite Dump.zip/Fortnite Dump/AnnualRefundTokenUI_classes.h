// Class AnnualRefundTokenUI.FortAnnualRefundTicket
// Size: 0x268 (Inherited: 0x260)
struct UFortAnnualRefundTicket : UUserWidget {
	struct UCommonTextBlock* Text_AvailableDate; // 0x260(0x08)

	void OnUpdatePendingState(bool bIsPending); // Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnUpdatePendingState // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnUpdateAvailableState(bool bIsAvailable); // Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnUpdateAvailableState // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnPlayLockingAnimation(); // Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnPlayLockingAnimation // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
};

// Class AnnualRefundTokenUI.FortAnnualRefundTokenData
// Size: 0x4f0 (Inherited: 0x4c8)
struct UFortAnnualRefundTokenData : UFortGameFeatureData {
	struct TSoftClassPtr<UObject> PurchaseHistoryScreenClass; // 0x4c8(0x28)
};

// Class AnnualRefundTokenUI.FortPurchaseHistoryEntry
// Size: 0xc00 (Inherited: 0xbd0)
struct UFortPurchaseHistoryEntry : UCommonButtonBase {
	char pad_BD0[0x8]; // 0xbd0(0x08)
	struct UFortCosmeticItemCard* ItemCardClass; // 0xbd8(0x08)
	float CardWidthOverride; // 0xbe0(0x04)
	char pad_BE4[0x4]; // 0xbe4(0x04)
	struct UCommonTextBlock* Text_Name; // 0xbe8(0x08)
	struct TArray<struct FString> LootEntryItemTypesToExclude; // 0xbf0(0x10)

	void UpdateItemList(struct TArray<struct UFortCosmeticItemCard*>& ItemCards); // Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.UpdateItemList // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void SetupItemCard(struct UFortCosmeticItemCard* ItemCard, struct UFortItem* Item); // Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.SetupItemCard // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void SetPurchaseText(struct FText& PurchaseText, bool bHasBeenRefunded); // Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.SetPurchaseText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void OnSetHistory(bool bHasBeenRefunded, bool bIsTokenlessRefund, bool bPlayerHasTokens); // Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.OnSetHistory // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
};

// Class AnnualRefundTokenUI.FortPurchaseHistoryListView
// Size: 0x300 (Inherited: 0x220)
struct UFortPurchaseHistoryListView : UListViewBase {
	char pad_220[0xe0]; // 0x220(0xe0)
};

// Class AnnualRefundTokenUI.ReturnReasonDataWrapper
// Size: 0x40 (Inherited: 0x28)
struct UReturnReasonDataWrapper : UObject {
	char pad_28[0x18]; // 0x28(0x18)
};

// Class AnnualRefundTokenUI.FortPurchaseHistoryScreen
// Size: 0x468 (Inherited: 0x348)
struct UFortPurchaseHistoryScreen : UCommonActivatableWidget {
	struct FDataTableRowHandle BackAction; // 0x348(0x10)
	struct UFortRefundConfirmation* RefundConfirmationClass; // 0x358(0x08)
	struct UCommonButtonGroupBase* TabButtonGroup; // 0x360(0x08)
	struct UCommonActivatableWidgetSwitcher* Switcher_ItemList; // 0x368(0x08)
	float MinRefundSubmissionDelay; // 0x370(0x04)
	float MaxRefundSubmissionDelay; // 0x374(0x04)
	struct TArray<struct FText> ReturnReasons; // 0x378(0x10)
	struct TArray<struct UReturnReasonDataWrapper*> WrapperArray; // 0x388(0x10)
	char pad_398[0x10]; // 0x398(0x10)
	struct TArray<struct UFortItemDefinition*> SelectedItemDefs; // 0x3a8(0x10)
	char pad_3B8[0x30]; // 0x3b8(0x30)
	struct UFortPurchaseHistoryListView* ListView_Purchases; // 0x3e8(0x08)
	struct UCommonListView* ListView_Reasons; // 0x3f0(0x08)
	struct UCommonButtonBase* Button_RequestRefund; // 0x3f8(0x08)
	struct UCommonButtonBase* Button_CloseMobile; // 0x400(0x08)
	struct UCommonButtonBase* Button_PostApproval; // 0x408(0x08)
	struct UCommonTextBlock* Text_Desc; // 0x410(0x08)
	struct UCommonTextBlock* Text_RefundCount; // 0x418(0x08)
	struct UCommonTextBlock* Text_ResultTitle; // 0x420(0x08)
	struct UCommonTextBlock* Text_ResultDesc; // 0x428(0x08)
	struct UCommonTextBlock* Text_ResultMtxMsg; // 0x430(0x08)
	struct UCommonTextBlock* Text_RefundValue; // 0x438(0x08)
	struct UCommonRichTextBlock* RichText_WarningMsg; // 0x440(0x08)
	struct UScrollBox* ScrollBox_ItemsToReturn; // 0x448(0x08)
	struct UFortAnnualRefundTicket* RefundTicket_Left; // 0x450(0x08)
	struct UFortAnnualRefundTicket* RefundTicket_Center; // 0x458(0x08)
	struct UFortAnnualRefundTicket* RefundTicket_Right; // 0x460(0x08)

	void UpdateItemList(struct TArray<struct UCommonTextBlock*>& ItemsToReturn); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.UpdateItemList // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void OnPopulateView(enum class EPurchaseReturnStep CurrentStep); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnPopulateView // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnOpenSubmitRequest(bool bIsSelectionTokenlessRefundable); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnOpenSubmitRequest // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnNoPurchasesAvailable(); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnNoPurchasesAvailable // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnItemRefresh(struct FMtxPurchaseHistory PurchaseHistory); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnItemRefresh // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnEndRefundSubmission(); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnEndRefundSubmission // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnBeginRefundSubmission(); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnBeginRefundSubmission // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void HandleTabButtonClicked(enum class EPurchaseReturnStep ClickedStep); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.HandleTabButtonClicked // (Final|Native|Private|BlueprintCallable) // @ game+0x39f5004
	void HandlePreviousStepAction(); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.HandlePreviousStepAction // (Final|Native|Private|BlueprintCallable) // @ game+0x39f4ff0
	enum class EPurchaseReturnStep GetCurrentStep(); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.GetCurrentStep // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x39f4fcc
};

// Class AnnualRefundTokenUI.FortRefundConfirmation
// Size: 0x3a0 (Inherited: 0x348)
struct UFortRefundConfirmation : UCommonActivatableWidget {
	char pad_348[0x10]; // 0x348(0x10)
	struct UCommonTextBlock* Text_RefundsRemaining; // 0x358(0x08)
	struct UCommonTextBlock* Text_RefundCount; // 0x360(0x08)
	struct UCommonTextBlock* Text_AreYouSure; // 0x368(0x08)
	struct UCommonButtonBase* Button_Yes; // 0x370(0x08)
	struct UCommonButtonBase* Button_No; // 0x378(0x08)
	struct UCommonButtonBase* Button_CloseMobile; // 0x380(0x08)
	struct UFortAnnualRefundTicket* RefundTicket_Left; // 0x388(0x08)
	struct UFortAnnualRefundTicket* RefundTicket_Center; // 0x390(0x08)
	struct UFortAnnualRefundTicket* RefundTicket_Right; // 0x398(0x08)
};

// Class AnnualRefundTokenUI.FortReturnReasonEntry
// Size: 0xbe8 (Inherited: 0xbd0)
struct UFortReturnReasonEntry : UCommonButtonBase {
	char pad_BD0[0x8]; // 0xbd0(0x08)
	struct UObject* InternalData; // 0xbd8(0x08)
	struct UCommonTextBlock* Text_Name; // 0xbe0(0x08)
};


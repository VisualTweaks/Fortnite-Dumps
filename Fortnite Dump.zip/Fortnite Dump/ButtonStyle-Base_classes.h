// BlueprintGeneratedClass ButtonStyle-Base.ButtonStyle-Base_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Base_C : UCommonButtonStyle {
};


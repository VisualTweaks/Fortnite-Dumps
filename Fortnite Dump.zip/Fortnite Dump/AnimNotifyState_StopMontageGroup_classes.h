// BlueprintGeneratedClass AnimNotifyState_StopMontageGroup.AnimNotifyState_StopMontageGroup_C
// Size: 0x3c (Inherited: 0x30)
struct UAnimNotifyState_StopMontageGroup_C : UAnimNotifyState {
	struct FName GroupNameToStop; // 0x30(0x08)
	float BlendOutTime; // 0x38(0x04)

	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_StopMontageGroup.AnimNotifyState_StopMontageGroup_C.Received_NotifyBegin // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xd6d38c
};


// Enum DiscoveryBrowserUI.EFortActivityBrowserTagType
enum class EFortActivityBrowserTagType : uint8 {
	Default = 0,
	EpicOriginal = 1,
	SquadSize = 2,
	MaxPlayers = 3,
	XP = 4,
	EFortActivityBrowserTagType_MAX = 5
};

// ScriptStruct DiscoveryBrowserUI.FortActivityScaleFontData
// Size: 0x08 (Inherited: 0x00)
struct FFortActivityScaleFontData {
	int32_t CharacterCountStart; // 0x00(0x04)
	int32_t FontSize; // 0x04(0x04)
};


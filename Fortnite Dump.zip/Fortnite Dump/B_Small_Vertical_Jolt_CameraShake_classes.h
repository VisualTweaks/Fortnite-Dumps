// BlueprintGeneratedClass B_Small_Vertical_Jolt_CameraShake.B_Small_Vertical_Jolt_CameraShake_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UB_Small_Vertical_Jolt_CameraShake_C : UMatineeCameraShake {
};


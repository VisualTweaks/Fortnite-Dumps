// Enum DynamicHUD.EDynamicHUDComparison
enum class EDynamicHUDComparison : uint8 {
	Equal = 0,
	LessOrEqual = 1,
	GreaterOrEqual = 2,
	EDynamicHUDComparison_MAX = 3
};

// Enum DynamicHUD.EDynamicHUDOperator
enum class EDynamicHUDOperator : uint8 {
	Addition = 0,
	Substraction = 1,
	EDynamicHUDOperator_MAX = 2
};

// Enum DynamicHUD.EDynamicHUDSide
enum class EDynamicHUDSide : uint8 {
	Top = 0,
	Bottom = 1,
	Left = 2,
	Right = 3,
	EDynamicHUDSide_MAX = 4
};

// Enum DynamicHUD.EDynamicHUDAnchor
enum class EDynamicHUDAnchor : uint8 {
	TopLeft = 0,
	TopCenter = 1,
	TopRight = 2,
	CenterLeft = 3,
	CenterCenter = 4,
	CenterRight = 5,
	BottomLeft = 6,
	BottomCenter = 7,
	BottomRight = 8,
	EDynamicHUDAnchor_MAX = 9
};

// Enum DynamicHUD.EDynamicHUDStrength
enum class EDynamicHUDStrength : uint8 {
	Weak = 0,
	Medium = 1,
	Strong = 2,
	Required = 3,
	EDynamicHUDStrength_MAX = 4
};

// Enum DynamicHUD.EDynamicHUDZOrder
enum class EDynamicHUDZOrder : int32 {
	Back = 500,
	Middle = 1000,
	Front = 1500,
	Custom = 2000,
	EDynamicHUDZOrder_MAX = 2001
};

// ScriptStruct DynamicHUD.DynamicHUDConstraintWidgetFallback
// Size: 0x30 (Inherited: 0x00)
struct FDynamicHUDConstraintWidgetFallback {
	struct TSoftClassPtr<UObject> TargetWidget; // 0x00(0x28)
	struct FName TargetUniqueID; // 0x28(0x08)
};

// ScriptStruct DynamicHUD.DirectorData
// Size: 0x38 (Inherited: 0x00)
struct FDirectorData {
	struct TSoftClassPtr<UObject> DirectorClass; // 0x00(0x28)
	struct AActor* Instance; // 0x28(0x08)
	char pad_30[0x8]; // 0x30(0x08)
};

// ScriptStruct DynamicHUD.ContextData
// Size: 0x10 (Inherited: 0x00)
struct FContextData {
	struct TArray<struct TWeakObjectPtr<struct UObject>> Contexts; // 0x00(0x10)
};

// ScriptStruct DynamicHUD.DynamicHUDUnallowed
// Size: 0x38 (Inherited: 0x00)
struct FDynamicHUDUnallowed {
	struct TSoftClassPtr<UObject> Widget; // 0x00(0x28)
	bool bUseUniqueID; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	struct FName UniqueId; // 0x2c(0x08)
	bool bIncludeAll; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
};

// ScriptStruct DynamicHUD.DynamicHUDAllowed
// Size: 0x48 (Inherited: 0x00)
struct FDynamicHUDAllowed {
	struct TSoftClassPtr<UObject> Widget; // 0x00(0x28)
	enum class EDynamicHUDZOrder ZOrder; // 0x28(0x04)
	int32_t CustomZOrder; // 0x2c(0x04)
	bool bIsUnique; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FName UniqueId; // 0x34(0x08)
	bool bUseSafeZone; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	struct UDynamicHUDConstraintBase* LayoutConstraint; // 0x40(0x08)
};


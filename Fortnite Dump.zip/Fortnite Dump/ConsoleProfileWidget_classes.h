// WidgetBlueprintGeneratedClass ConsoleProfileWidget.ConsoleProfileWidget_C
// Size: 0x278 (Inherited: 0x278)
struct UConsoleProfileWidget_C : UFortConsoleProfileWidget {
};


// BlueprintGeneratedClass Border-SolidBG-ToolTipShadow.Border-SolidBG-ToolTipShadow_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-SolidBG-ToolTipShadow_C : UBorder-ShellTopBar_C {
};


// UserDefinedEnum En_ShellTypes_01.En_ShellTypes_01
enum class En_ShellTypes_01 : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	NewEnumerator4 = 4,
	En_ShellTypes_MAX = 5
};


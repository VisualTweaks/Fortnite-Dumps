// BlueprintGeneratedClass Border-SolidBG-ToolTip.Border-SolidBG-ToolTip_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-SolidBG-ToolTip_C : UBorder-ShellTopBar_C {
};


// BlueprintGeneratedClass Border-TabM.Border-TabM_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-TabM_C : UCommonBorderStyle {
};


// WidgetBlueprintGeneratedClass ControllerActionsMenu.ControllerActionsMenu_C
// Size: 0x4b0 (Inherited: 0x4a8)
struct UControllerActionsMenu_C : UFortControllerActionsMenu {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a8(0x08)

	void BP_OnActivated(); // Function ControllerActionsMenu.ControllerActionsMenu_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_ControllerActionsMenu(int32_t EntryPoint); // Function ControllerActionsMenu.ControllerActionsMenu_C.ExecuteUbergraph_ControllerActionsMenu // (Final|UbergraphFunction) // @ game+0xd6d38c
};


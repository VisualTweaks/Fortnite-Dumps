// BlueprintGeneratedClass ButtonStyle-Skew_Green.ButtonStyle-Skew_Green_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Skew_Green_C : UCommonButtonStyle {
};


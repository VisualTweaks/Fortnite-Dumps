// BlueprintGeneratedClass Border-HeroLoadoutWarningStyle.Border-HeroLoadoutWarningStyle_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-HeroLoadoutWarningStyle_C : UCommonBorderStyle {
};


// WidgetBlueprintGeneratedClass ControllerDisconnectedModal.ControllerDisconnectedModal_C
// Size: 0x5a0 (Inherited: 0x588)
struct UControllerDisconnectedModal_C : UFortControllerDisconnectedModal {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x588(0x08)
	struct UCommonActionWidget* CommonActionWidget_165; // 0x590(0x08)
	struct ULightbox_C* Lightbox; // 0x598(0x08)

	struct FEventReply OnAnalogValueChanged(struct FGeometry MyGeometry, struct FAnalogInputEvent InAnalogInputEvent); // Function ControllerDisconnectedModal.ControllerDisconnectedModal_C.OnAnalogValueChanged // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Construct(); // Function ControllerDisconnectedModal.ControllerDisconnectedModal_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_ControllerDisconnectedModal(int32_t EntryPoint); // Function ControllerDisconnectedModal.ControllerDisconnectedModal_C.ExecuteUbergraph_ControllerDisconnectedModal // (Final|UbergraphFunction) // @ game+0xd6d38c
};


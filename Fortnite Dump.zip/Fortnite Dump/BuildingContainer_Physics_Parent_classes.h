// BlueprintGeneratedClass BuildingContainer_Physics_Parent.BuildingContainer_Physics_Parent_C
// Size: 0xed1 (Inherited: 0xeb0)
struct ABuildingContainer_Physics_Parent_C : ABuildingContainer {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xeb0(0x08)
	struct UFortLinkToActorComponent* FortLinkToActor; // 0xeb8(0x08)
	struct UFortPhysicsObjectComponent* FortPhysicsObject; // 0xec0(0x08)
	struct AActor* LinkedActor; // 0xec8(0x08)
	bool Rep_WakeUp; // 0xed0(0x01)

	void OnRep_Rep_WakeUp(); // Function BuildingContainer_Physics_Parent.BuildingContainer_Physics_Parent_C.OnRep_Rep_WakeUp // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_1_OnLinkedActorDestroyed__DelegateSignature(); // Function BuildingContainer_Physics_Parent.BuildingContainer_Physics_Parent_C.BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_1_OnLinkedActorDestroyed__DelegateSignature // (BlueprintEvent) // @ game+0xd6d38c
	void BndEvt__FortPhysicsObject_K2Node_ComponentBoundEvent_0_OnPhysicsObjectAwakeChanged__DelegateSignature(struct UPrimitiveComponent* SimulatingComponent, bool bIsAwake); // Function BuildingContainer_Physics_Parent.BuildingContainer_Physics_Parent_C.BndEvt__FortPhysicsObject_K2Node_ComponentBoundEvent_0_OnPhysicsObjectAwakeChanged__DelegateSignature // (BlueprintEvent) // @ game+0xd6d38c
	void ReceiveBeginPlay(); // Function BuildingContainer_Physics_Parent.BuildingContainer_Physics_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_BuildingContainer_Physics_Parent(int32_t EntryPoint); // Function BuildingContainer_Physics_Parent.BuildingContainer_Physics_Parent_C.ExecuteUbergraph_BuildingContainer_Physics_Parent // (Final|UbergraphFunction) // @ game+0xd6d38c
};


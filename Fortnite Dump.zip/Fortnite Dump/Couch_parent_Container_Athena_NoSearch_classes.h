// BlueprintGeneratedClass Couch_parent_Container_Athena_NoSearch.Couch_parent_Container_Athena_NoSearch_C
// Size: 0xdc1 (Inherited: 0xdc1)
struct ACouch_parent_Container_Athena_NoSearch_C : AHotfix_BuildingPropWithLootComp_Parent_C {
};


// UserDefinedEnum E_Creative_Powerup_TeamRelationshipVisibility.E_Creative_Powerup_TeamRelationshipVisibility
enum class E_Creative_Powerup_TeamRelationshipVisibility : uint8 {
	NewEnumerator1 = 0,
	NewEnumerator0 = 1,
	E_Creative_Powerup_MAX = 2
};


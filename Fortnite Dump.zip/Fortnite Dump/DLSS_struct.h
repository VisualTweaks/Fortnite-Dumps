// Enum DLSS.EDLSSSettingOverride
enum class EDLSSSettingOverride : uint8 {
	Enabled = 0,
	Disabled = 1,
	UseProjectSettings = 2,
	EDLSSSettingOverride_MAX = 3
};


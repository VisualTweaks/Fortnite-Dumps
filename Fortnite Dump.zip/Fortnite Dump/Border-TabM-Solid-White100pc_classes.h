// BlueprintGeneratedClass Border-TabM-Solid-White100pc.Border-TabM-Solid-White100pc_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-TabM-Solid-White100pc_C : UBorder-TabM-Solid_C {
};


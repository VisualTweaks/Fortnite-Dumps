// Class BlueCheeseRuntime.FortAthenaMutator_BlueCheese
// Size: 0x2c8 (Inherited: 0x2c8)
struct AFortAthenaMutator_BlueCheese : AFortAthenaMutator {
};


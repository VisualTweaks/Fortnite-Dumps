// WidgetBlueprintGeneratedClass ConfirmationButton.ConfirmationButton_C
// Size: 0xd21 (Inherited: 0xd21)
struct UConfirmationButton_C : UIconTextButton_C {
};


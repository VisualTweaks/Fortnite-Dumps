// BlueprintGeneratedClass BP_ZippyTroutTrap_Ceiling.BP_ZippyTroutTrap_Ceiling_C
// Size: 0xee9 (Inherited: 0xee9)
struct ABP_ZippyTroutTrap_Ceiling_C : ABP_ZippyTroutTrap_Floor_C {
};


// BlueprintGeneratedClass Border-ItemInfo-Unlocked.Border-ItemInfo-Unlocked_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-ItemInfo-Unlocked_C : UCommonBorderStyle {
};


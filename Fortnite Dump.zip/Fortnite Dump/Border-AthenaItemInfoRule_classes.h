// BlueprintGeneratedClass Border-AthenaItemInfoRule.Border-AthenaItemInfoRule_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-AthenaItemInfoRule_C : UCommonBorderStyle {
};


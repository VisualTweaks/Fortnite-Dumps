// Class DiscoveryBrowserUI.ActivityLibraryComponent
// Size: 0xc0 (Inherited: 0xb0)
struct UActivityLibraryComponent : UActorComponent {
	char pad_B0[0x10]; // 0xb0(0x10)
};

// Class DiscoveryBrowserUI.FortActivityBrowser
// Size: 0x520 (Inherited: 0x348)
struct UFortActivityBrowser : UCommonActivatableWidget {
	char pad_348[0x8]; // 0x348(0x08)
	struct UCommonActivatableWidgetSwitcher* Switcher_ActivityBrowserViews; // 0x350(0x08)
	struct UCommonButtonBase* Button_Back; // 0x358(0x08)
	struct UCommonButtonBase* Button_ShowCustomMatchmakingModal; // 0x360(0x08)
	struct UCommonButtonBase* Button_BackToTop; // 0x368(0x08)
	struct UCommonButtonBase* Button_MobileShowGameDetails; // 0x370(0x08)
	struct UCommonButtonBase* Button_MobileAccept; // 0x378(0x08)
	struct UCommonButtonBase* Button_MobileClose; // 0x380(0x08)
	struct UCommonButtonBase* Button_JoinAsSpectator; // 0x388(0x08)
	struct UCommonButtonBase* Button_ShowSpectateMatchModal; // 0x390(0x08)
	struct UFortTabListWidgetBase* TabList_BrowserTabs; // 0x398(0x08)
	struct FPrimaryContentSetup PrimaryContentSetup; // 0x3a0(0x01)
	char pad_3A1[0x7]; // 0x3a1(0x07)
	struct UFortTabButton* TabButtonClass; // 0x3a8(0x08)
	struct UFortActivityDetailsModal* ActivityDetailsModalClass; // 0x3b0(0x08)
	struct TSoftClassPtr<UObject> SoftCustomMatchmakingModalClass; // 0x3b8(0x28)
	struct TSoftClassPtr<UObject> SoftSpectateMatchModalClass; // 0x3e0(0x28)
	struct UFortCreativeDiscoverySurfaceManager* Manager; // 0x408(0x08)
	struct UFortCreativeDiscoverySurface* Surface; // 0x410(0x08)
	struct TArray<struct UFortCreativeDiscoveryActivityProvider*> CachedSurfaceActivityProviders; // 0x418(0x10)
	char pad_428[0xf8]; // 0x428(0xf8)

	void OnPlayerQueueTypeChanged(enum class EPlayerQueueType PlayerQueueType); // Function DiscoveryBrowserUI.FortActivityBrowser.OnPlayerQueueTypeChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnActivitySelected(); // Function DiscoveryBrowserUI.FortActivityBrowser.OnActivitySelected // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void HandleTabChanged(struct FName TabId); // Function DiscoveryBrowserUI.FortActivityBrowser.HandleTabChanged // (Final|Native|Private) // @ game+0x408576c
};

// Class DiscoveryBrowserUI.FortActivityBrowserListView
// Size: 0x370 (Inherited: 0x220)
struct UFortActivityBrowserListView : UListViewBase {
	char pad_220[0xc0]; // 0x220(0xc0)
	float DirectionalNavigationTimeThreshold; // 0x2e0(0x04)
	char pad_2E4[0x4]; // 0x2e4(0x04)
	struct UFortActivityBrowserRow* PromotedActivityClass; // 0x2e8(0x08)
	char pad_2F0[0x80]; // 0x2f0(0x80)
};

// Class DiscoveryBrowserUI.FortActivityBrowserRow
// Size: 0x2f0 (Inherited: 0x288)
struct UFortActivityBrowserRow : UCommonUserWidget {
	char pad_288[0x60]; // 0x288(0x60)
	struct UCommonTextBlock* Text_CategoryName; // 0x2e8(0x08)

	void OnRowPeekStateChanged(bool bIsInPeekState); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowPeekStateChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnRowMoveUp(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowMoveUp // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnRowMoveDown(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowMoveDown // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnRowIsActiveChanged(bool bIsActive); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowIsActiveChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnCategoryItemChanged(bool bIsActive, bool bPlayAnimation); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnCategoryItemChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	bool GetIsInPeekState(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsInPeekState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x408567c
	bool GetIsActive(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4085654
};

// Class DiscoveryBrowserUI.FortActivityBrowserRowList
// Size: 0x310 (Inherited: 0x2f0)
struct UFortActivityBrowserRowList : UFortActivityBrowserRow {
	struct UFortActivityListView* ListView_Activities; // 0x2f0(0x08)
	struct UCommonButtonBase* Button_PageLeft; // 0x2f8(0x08)
	struct UCommonButtonBase* Button_PageRight; // 0x300(0x08)
	char pad_308[0x8]; // 0x308(0x08)

	void OnQueryStatusChanged(bool bIsActive); // Function DiscoveryBrowserUI.FortActivityBrowserRowList.OnQueryStatusChanged // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
};

// Class DiscoveryBrowserUI.FortActivityBrowserRowPromoted
// Size: 0x2f8 (Inherited: 0x2f0)
struct UFortActivityBrowserRowPromoted : UFortActivityBrowserRow {
	struct UCommonTextBlock* Text_ActivityName; // 0x2f0(0x08)

	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* Texture); // Function DiscoveryBrowserUI.FortActivityBrowserRowPromoted.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
};

// Class DiscoveryBrowserUI.FortActivityBrowserSoloButton
// Size: 0xcf0 (Inherited: 0xc20)
struct UFortActivityBrowserSoloButton : UCommonButtonLegacy {
	struct FText DefaultText; // 0xc20(0x18)
	bool bUseAllCaps; // 0xc38(0x01)
	bool bOverrideFont; // 0xc39(0x01)
	char pad_C3A[0x6]; // 0xc3a(0x06)
	struct FSlateFontInfo Font; // 0xc40(0x58)
	struct FSlateColor FontColor; // 0xc98(0x28)
	struct UCommonTextBlock* Text_Content; // 0xcc0(0x08)
	float MinWidthOverride; // 0xcc8(0x04)
	float MinHeightOverride; // 0xccc(0x04)
	struct FMargin TextPaddingOverride; // 0xcd0(0x10)
	int32_t FontSizeOverride; // 0xce0(0x04)
	char pad_CE4[0x4]; // 0xce4(0x04)
	struct UMaterialInterface* MaterialOverride; // 0xce8(0x08)
};

// Class DiscoveryBrowserUI.FortActivityBrowserTabButton
// Size: 0xbf0 (Inherited: 0xbf0)
struct UFortActivityBrowserTabButton : UFortTabButton {

	void OnFavoriteChanged(bool bIsFavorite); // Function DiscoveryBrowserUI.FortActivityBrowserTabButton.OnFavoriteChanged // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
};

// Class DiscoveryBrowserUI.FortActivityBrowserTag
// Size: 0x270 (Inherited: 0x260)
struct UFortActivityBrowserTag : UUserWidget {
	struct UCommonTextBlock* Text_TagDescription; // 0x260(0x08)
	char pad_268[0x8]; // 0x268(0x08)

	void OnTagUpdated(); // Function DiscoveryBrowserUI.FortActivityBrowserTag.OnTagUpdated // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	enum class EFortActivityBrowserTagType GetTagType(); // Function DiscoveryBrowserUI.FortActivityBrowserTag.GetTagType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x40856a4
};

// Class DiscoveryBrowserUI.FortActivityBrowserTile
// Size: 0x350 (Inherited: 0x288)
struct UFortActivityBrowserTile : UCommonUserWidget {
	char pad_288[0x8]; // 0x288(0x08)
	struct UFortActivityTileDetailsDisplay* Display_TileDetails; // 0x290(0x08)
	char pad_298[0xb8]; // 0x298(0xb8)

	void HandleActivitySelected(); // Function DiscoveryBrowserUI.FortActivityBrowserTile.HandleActivitySelected // (Final|Native|Private) // @ game+0x40856bc
};

// Class DiscoveryBrowserUI.FortActivityView
// Size: 0x420 (Inherited: 0x348)
struct UFortActivityView : UCommonActivatableWidget {
	char pad_348[0x8]; // 0x348(0x08)
	bool bShowCustomMatchmakingModalButton; // 0x350(0x01)
	bool bShowSpectateMatchModalButton; // 0x351(0x01)
	bool bShowMobileGameDetailsButton; // 0x352(0x01)
	bool bShowMobileAcceptButton; // 0x353(0x01)
	bool bShowBackToTopButton; // 0x354(0x01)
	char pad_355[0xcb]; // 0x355(0xcb)

	void OnSurfaceDataDirty(); // Function DiscoveryBrowserUI.FortActivityView.OnSurfaceDataDirty // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	enum class EFortInvalidActivityReason GetInvalidActivityReason(); // Function DiscoveryBrowserUI.FortActivityView.GetInvalidActivityReason // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x40855f4
	void BP_OnPartySizeChanged(int32_t PartySize); // Function DiscoveryBrowserUI.FortActivityView.BP_OnPartySizeChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void BP_OnLocalPlayerPromotedToLeader(); // Function DiscoveryBrowserUI.FortActivityView.BP_OnLocalPlayerPromotedToLeader // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void BP_OnLocalPlayerDemoted(); // Function DiscoveryBrowserUI.FortActivityView.BP_OnLocalPlayerDemoted // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
};

// Class DiscoveryBrowserUI.FortActivityBrowserView
// Size: 0x590 (Inherited: 0x420)
struct UFortActivityBrowserView : UFortActivityView {
	char pad_420[0x8]; // 0x420(0x08)
	float MouseWheelScrollTimeThreshold; // 0x428(0x04)
	char pad_42C[0x4]; // 0x42c(0x04)
	struct TArray<struct FString> ActivityMovieBlacklist; // 0x430(0x10)
	struct TArray<enum class ECommonPlatformType> PlatformMovieBlacklist; // 0x440(0x10)
	struct FName TabNameID; // 0x450(0x08)
	struct FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x458(0xa0)
	bool bPlayDetailsAnimationOnScreenOpen; // 0x4f8(0x01)
	char pad_4F9[0x7]; // 0x4f9(0x07)
	struct UFortActivatableMovieWidget* MovieWidgetClass; // 0x500(0x08)
	struct UFortSwipePanel* SwipePanel_Navigation; // 0x508(0x08)
	struct UFortActivityDetailsDisplay* DetailsDisplay_SelectedActivity; // 0x510(0x08)
	struct UFortActivityDetailsDisplay* DetailsDisplay_PromotedActivity; // 0x518(0x08)
	struct UFortActivityBrowserListView* BrowserList_Activities; // 0x520(0x08)
	struct UPanelWidget* Panel_VideoSlot; // 0x528(0x08)
	struct UFortActivatableMovieWidget* ActivityMovieWidget; // 0x530(0x08)
	char pad_538[0x58]; // 0x538(0x58)

	void OnRowChanged(int32_t NewCategoryIndex); // Function DiscoveryBrowserUI.FortActivityBrowserView.OnRowChanged // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnQueryActivitiesFinished(); // Function DiscoveryBrowserUI.FortActivityBrowserView.OnQueryActivitiesFinished // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* Texture); // Function DiscoveryBrowserUI.FortActivityBrowserView.OnPreviewImageChanged // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnMoviePlayingChanged(bool bIsPlaying); // Function DiscoveryBrowserUI.FortActivityBrowserView.OnMoviePlayingChanged // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnActivityUpdated(); // Function DiscoveryBrowserUI.FortActivityBrowserView.OnActivityUpdated // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	bool IsShowingPromotedContent(); // Function DiscoveryBrowserUI.FortActivityBrowserView.IsShowingPromotedContent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4085a78
	void HandleMovieWidgetMediaStarted(); // Function DiscoveryBrowserUI.FortActivityBrowserView.HandleMovieWidgetMediaStarted // (Final|Native|Private) // @ game+0x40856e4
};

// Class DiscoveryBrowserUI.FortActivityCreateView
// Size: 0x4e8 (Inherited: 0x420)
struct UFortActivityCreateView : UFortActivityView {
	char pad_420[0x8]; // 0x420(0x08)
	struct FName TabNameID; // 0x428(0x08)
	struct FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x430(0xa0)
	struct UCommonButtonBase* Button_Create; // 0x4d0(0x08)
	char pad_4D8[0x10]; // 0x4d8(0x10)

	enum class EFortInvalidActivityReason GetInvalidCreativeActivityReason(); // Function DiscoveryBrowserUI.FortActivityCreateView.GetInvalidCreativeActivityReason // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x4085628
};

// Class DiscoveryBrowserUI.FortActivityDetailsDisplay
// Size: 0x358 (Inherited: 0x288)
struct UFortActivityDetailsDisplay : UCommonUserWidget {
	char pad_288[0x60]; // 0x288(0x60)
	struct TArray<struct FString> XpTagMnemonicWhitelist; // 0x2e8(0x10)
	float IntroDelay; // 0x2f8(0x04)
	float DetailsScrollStartDelay; // 0x2fc(0x04)
	float DetailsScrollSpeed; // 0x300(0x04)
	float DetailsScrollEndDelay; // 0x304(0x04)
	struct UCommonRichTextBlock* Text_ActivityOrigin; // 0x308(0x08)
	struct UCommonTextBlock* Text_ActivityName; // 0x310(0x08)
	struct UCommonTextBlock* Text_ActivityDescription; // 0x318(0x08)
	struct UScrollBox* ScrollBox_ActivityDescription; // 0x320(0x08)
	struct UDynamicEntryBox* EntryBox_ActivityTags; // 0x328(0x08)
	struct UWidgetAnimation* DetailsIntro; // 0x330(0x08)
	struct UWidgetAnimation* DetailsOutro; // 0x338(0x08)
	struct UCommonButtonBase* Button_Accept; // 0x340(0x08)
	struct UCommonButtonBase* Button_Details; // 0x348(0x08)
	struct UCommonButtonBase* Button_Favorite; // 0x350(0x08)

	void ResetWidgetState(); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.ResetWidgetState // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnPartySizeChanged(int32_t PartySize); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.OnPartySizeChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnParentActivated(); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.OnParentActivated // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnOutroAnimationFinished(); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.OnOutroAnimationFinished // (Final|Native|Private) // @ game+0x4085ad0
	void OnLocalPlayerPromotedToLeader(); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.OnLocalPlayerPromotedToLeader // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnLocalPlayerDemoted(); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.OnLocalPlayerDemoted // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnIsFavoriteChanged(bool bIsFavorite, bool bPlayAnimation); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.OnIsFavoriteChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnDetailsUpdated(bool bIsDetailsValid); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.OnDetailsUpdated // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnDescriptionScrollRestarted(); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.OnDescriptionScrollRestarted // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	bool IsActivityEpicOriginal(); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.IsActivityEpicOriginal // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4085a34
	enum class EFortInvalidActivityReason GetInvalidActivityReason(); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.GetInvalidActivityReason // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2fe3290
	struct FText GetCreatorTextFormat(struct FText& CreatorName); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.GetCreatorTextFormat // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4085480
	struct TArray<struct FString> GetContentWarningStrings(); // Function DiscoveryBrowserUI.FortActivityDetailsDisplay.GetContentWarningStrings // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2fe3240
};

// Class DiscoveryBrowserUI.FortActivityDetailsModal
// Size: 0x478 (Inherited: 0x420)
struct UFortActivityDetailsModal : UFortActivityView {
	struct UCommonTextBlock* Text_LinkCode; // 0x420(0x08)
	struct UCommonTextBlock* Text_LinkCodeVersion; // 0x428(0x08)
	struct UFortActivityDetailsDisplay* DetailsDisplay_SelectedActivity; // 0x430(0x08)
	struct UCommonButtonBase* Button_MobileClose; // 0x438(0x08)
	struct UCommonButtonBase* Button_Back; // 0x440(0x08)
	struct UCommonButtonBase* Button_BackBoard; // 0x448(0x08)
	struct UCommonButtonBase* Button_Favorite; // 0x450(0x08)
	char pad_458[0x20]; // 0x458(0x20)

	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* Texture); // Function DiscoveryBrowserUI.FortActivityDetailsModal.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnIsFavoriteChanged(bool bIsFavorite); // Function DiscoveryBrowserUI.FortActivityDetailsModal.OnIsFavoriteChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
};

// Class DiscoveryBrowserUI.FortActivityEllipsisTextBlock
// Size: 0x290 (Inherited: 0x260)
struct UFortActivityEllipsisTextBlock : UUserWidget {
	struct UWidget* Widget_ClippingArea; // 0x260(0x08)
	struct UCommonTextBlock* Text_Text; // 0x268(0x08)
	struct UWidget* Widget_MoreTextIndicator; // 0x270(0x08)
	char pad_278[0x18]; // 0x278(0x18)
};

// Class DiscoveryBrowserUI.FortActivityPlayerBrowserView
// Size: 0x510 (Inherited: 0x420)
struct UFortActivityPlayerBrowserView : UFortActivityView {
	char pad_420[0x8]; // 0x420(0x08)
	struct UFortGameActivityProvider* ActivityProvider; // 0x428(0x08)
	struct FName TabNameID; // 0x430(0x08)
	struct FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x438(0xa0)
	enum class EFortCreativeDiscoveryPlayHistoryType PlayHistoryProviderType; // 0x4d8(0x01)
	char pad_4D9[0x7]; // 0x4d9(0x07)
	struct UFortGameActivityProvider* ActivityProviderClass; // 0x4e0(0x08)
	struct UFortActivityTileView* TileView_PlayerActivities; // 0x4e8(0x08)
	char pad_4F0[0x20]; // 0x4f0(0x20)

	void PlayViewIntro(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.PlayViewIntro // (Final|Native|Public|BlueprintCallable) // @ game+0x4085ae4
	void OnPlayViewIntro(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.OnPlayViewIntro // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void BP_OnTileViewUpdated(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.BP_OnTileViewUpdated // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
};

// Class DiscoveryBrowserUI.FortActivityFavoriteBrowserView
// Size: 0x560 (Inherited: 0x510)
struct UFortActivityFavoriteBrowserView : UFortActivityPlayerBrowserView {
	char pad_510[0x50]; // 0x510(0x50)
};

// Class DiscoveryBrowserUI.FortActivityListItemWrapper
// Size: 0x38 (Inherited: 0x28)
struct UFortActivityListItemWrapper : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class DiscoveryBrowserUI.FortActivityListView
// Size: 0x310 (Inherited: 0x220)
struct UFortActivityListView : UListViewBase {
	char pad_220[0xc0]; // 0x220(0xc0)
	float DirectionalNavigationTimeThreshold; // 0x2e0(0x04)
	enum class EOrientation Orientation; // 0x2e4(0x01)
	char pad_2E5[0x3]; // 0x2e5(0x03)
	float EntrySpacing; // 0x2e8(0x04)
	char pad_2EC[0x24]; // 0x2ec(0x24)

	int32_t GetInViewCount(); // Function DiscoveryBrowserUI.FortActivityListView.GetInViewCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x40855a4
};

// Class DiscoveryBrowserUI.FortActivityLobbyTile
// Size: 0xc58 (Inherited: 0xc20)
struct UFortActivityLobbyTile : UCommonButtonLegacy {
	struct UCommonTextBlock* Text_ActivityName; // 0xc20(0x08)
	struct UFortActivityBrowserTag* ActivityBrowserTag_EpicOriginal; // 0xc28(0x08)
	struct UFortGameActivityProvider* ActivityProvider; // 0xc30(0x08)
	char pad_C38[0x20]; // 0xc38(0x20)

	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* Texture); // Function DiscoveryBrowserUI.FortActivityLobbyTile.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnDetailsUpdated(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.OnDetailsUpdated // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	bool IsActivityEpicCreated(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.IsActivityEpicCreated // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x40859d8
};

// Class DiscoveryBrowserUI.FortActivityPlayerBrowserTile
// Size: 0x358 (Inherited: 0x288)
struct UFortActivityPlayerBrowserTile : UCommonUserWidget {
	char pad_288[0x8]; // 0x288(0x08)
	struct UFortActivityTileDetailsDisplay* Display_TileDetails; // 0x290(0x08)
	struct UCommonTextBlock* Text_LastPlayedDate; // 0x298(0x08)
	char pad_2A0[0xb8]; // 0x2a0(0xb8)

	void HandleActivitySelected(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserTile.HandleActivitySelected // (Final|Native|Private) // @ game+0x40856d0
};

// Class DiscoveryBrowserUI.FortActivityPlayerView
// Size: 0x510 (Inherited: 0x420)
struct UFortActivityPlayerView : UFortActivityView {
	char pad_420[0x8]; // 0x420(0x08)
	struct FName TabNameID; // 0x428(0x08)
	struct FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x430(0xa0)
	struct UCommonButtonBase* TabButtonClass; // 0x4d0(0x08)
	struct UFortTabListWidgetBase* TabList_PlayerViewTabs; // 0x4d8(0x08)
	struct UCommonActivatableWidgetSwitcher* Switcher_PlayerBrowserViews; // 0x4e0(0x08)
	struct UFortActivityPlayerBrowserView* BrowserView_Favorites; // 0x4e8(0x08)
	struct UFortActivityPlayerBrowserView* BrowserView_History; // 0x4f0(0x08)
	char pad_4F8[0x18]; // 0x4f8(0x18)
};

// Class DiscoveryBrowserUI.FortActivityPlayerViewTabButton
// Size: 0xbf8 (Inherited: 0xbf0)
struct UFortActivityPlayerViewTabButton : UFortTabButton {
	struct UCommonTextBlock* Text_Count; // 0xbf0(0x08)
};

// Class DiscoveryBrowserUI.FortActivityScaleFontList
// Size: 0x38 (Inherited: 0x28)
struct UFortActivityScaleFontList : UObject {
	struct TArray<struct FFortActivityScaleFontData> ScaleData; // 0x28(0x10)
};

// Class DiscoveryBrowserUI.FortActivityScalingTextBlock
// Size: 0x2d8 (Inherited: 0x2d0)
struct UFortActivityScalingTextBlock : UCommonTextBlock {
	struct UFortActivityScaleFontList* Scaling; // 0x2d0(0x08)
};

// Class DiscoveryBrowserUI.FortActivitySearchView
// Size: 0x520 (Inherited: 0x420)
struct UFortActivitySearchView : UFortActivityView {
	char pad_420[0x8]; // 0x420(0x08)
	struct FName TabNameID; // 0x428(0x08)
	struct FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x430(0xa0)
	struct UEditableText* EditableText_IslandLink; // 0x4d0(0x08)
	char pad_4D8[0x48]; // 0x4d8(0x48)

	void OnActivityValidated(enum class EFortActivityValidationResult ValidateResult); // Function DiscoveryBrowserUI.FortActivitySearchView.OnActivityValidated // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnActivityClear(); // Function DiscoveryBrowserUI.FortActivitySearchView.OnActivityClear // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void HandleTextCommitted(struct FText& InText, enum class ETextCommit CommitInfo); // Function DiscoveryBrowserUI.FortActivitySearchView.HandleTextCommitted // (Final|Native|Private|HasOutParms) // @ game+0x40858c8
	void HandleTextChanged(struct FText& Text); // Function DiscoveryBrowserUI.FortActivitySearchView.HandleTextChanged // (Final|Native|Private|HasOutParms) // @ game+0x4085804
};

// Class DiscoveryBrowserUI.FortActivityTileDetailsDisplay
// Size: 0xc80 (Inherited: 0xbd0)
struct UFortActivityTileDetailsDisplay : UCommonButtonBase {
	struct FMulticastInlineDelegate OnActivitySelectedDelegate; // 0xbd0(0x10)
	struct FMulticastInlineDelegate OnActivityUnSelectedDelegate; // 0xbe0(0x10)
	bool bShowDetailsButton; // 0xbf0(0x01)
	char pad_BF1[0x7]; // 0xbf1(0x07)
	struct UFortActivityEllipsisTextBlock* Text_ActivityName; // 0xbf8(0x08)
	struct UCommonTextBlock* Text_PlayerCount; // 0xc00(0x08)
	struct UCommonButtonBase* Button_Favorite; // 0xc08(0x08)
	struct UCommonButtonBase* Button_Details; // 0xc10(0x08)
	struct UFortActivityBrowserTag* ActivityBrowserTag_EpicOriginal; // 0xc18(0x08)
	char pad_C20[0x60]; // 0xc20(0x60)

	void OnTileActiveSet(bool bIsTileActive); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnTileActiveSet // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnSocialUsersPlayingChanged(int32_t NumPlaying); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnSocialUsersPlayingChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* Texture); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnPartySizeChanged(int32_t PartySize); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnPartySizeChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnLocalPlayerPromotedToLeader(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLocalPlayerPromotedToLeader // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnLocalPlayerDemoted(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLocalPlayerDemoted // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnIsFavoriteChanged(bool bIsFavorite); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnIsFavoriteChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnDetailsUpdated(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnDetailsUpdated // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnActivityUnSelected__DelegateSignature(); // DelegateFunction DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivityUnSelected__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0xd6d38c
	void OnActivitySelected__DelegateSignature(); // DelegateFunction DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivitySelected__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0xd6d38c
	bool IsActivityFavorited(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsActivityFavorited // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x4085a58
	bool IsActivityEpicCreated(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsActivityEpicCreated // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x4085a10
	enum class EFortInvalidActivityReason GetInvalidActivityReason(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.GetInvalidActivityReason // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x40855c8
};

// Class DiscoveryBrowserUI.FortActivityTileView
// Size: 0x860 (Inherited: 0x860)
struct UFortActivityTileView : UTileView {
};

// Class DiscoveryBrowserUI.OverrideMatchmakingUIComponent
// Size: 0x100 (Inherited: 0xb0)
struct UOverrideMatchmakingUIComponent : UActorComponent {
	struct FMatchmakingUIOverride MatchmakingUIOverride; // 0xb0(0x50)
};


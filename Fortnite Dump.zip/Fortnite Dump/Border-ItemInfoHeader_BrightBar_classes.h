// BlueprintGeneratedClass Border-ItemInfoHeader_BrightBar.Border-ItemInfoHeader_BrightBar_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-ItemInfoHeader_BrightBar_C : UBorder-ItemInfoHeader_C {
};


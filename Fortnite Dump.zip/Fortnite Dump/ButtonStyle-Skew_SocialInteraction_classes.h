// BlueprintGeneratedClass ButtonStyle-Skew_SocialInteraction.ButtonStyle-Skew_SocialInteraction_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Skew_SocialInteraction_C : UCommonButtonStyle {
};


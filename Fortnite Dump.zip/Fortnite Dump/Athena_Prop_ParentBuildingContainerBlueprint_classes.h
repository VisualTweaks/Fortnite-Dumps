// BlueprintGeneratedClass Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C
// Size: 0xe20 (Inherited: 0xd40)
struct AAthena_Prop_ParentBuildingContainerBlueprint_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd40(0x08)
	bool DebugWind; // 0xd48(0x01)
	char pad_D49[0x7]; // 0xd49(0x07)
	struct TArray<struct UMaterialInterface*> IntenseWindMaterialsForPreview; // 0xd50(0x10)
	struct UStaticMeshComponent* Wind Intensity Debug Mesh; // 0xd60(0x08)
	struct TArray<struct UMaterialInterface*> OriginalMaterials; // 0xd68(0x10)
	struct UMaterialInstanceDynamic* Debug_TempMaterial; // 0xd78(0x08)
	float DebugWindYaw; // 0xd80(0x04)
	float Debug Wind Intensity; // 0xd84(0x04)
	bool Set Max Actor Scale; // 0xd88(0x01)
	char pad_D89[0x3]; // 0xd89(0x03)
	float Max Scale; // 0xd8c(0x04)
	bool Disable TOD Lights and Material Emissive Values; // 0xd90(0x01)
	bool Disable Static Mesh Shadow Casting When Lights Are Active; // 0xd91(0x01)
	bool Use An Alternate Shadow Mesh When The Light is On ; // 0xd92(0x01)
	char pad_D93[0x5]; // 0xd93(0x05)
	struct UStaticMesh* AlternateShadowStaticMesh; // 0xd98(0x08)
	bool Animate Emissive and Lights Over Time; // 0xda0(0x01)
	char pad_DA1[0x7]; // 0xda1(0x07)
	struct TArray<struct FLinearColor> CodeControlled_EmissiveColor; // 0xda8(0x10)
	struct TArray<float> CodeControlled_LightConeOpacity; // 0xdb8(0x10)
	struct FDayPhaseFloats Light Intensity Over Time of Day ; // 0xdc8(0x10)
	float Day Phase Transition Length; // 0xdd8(0x04)
	struct FDayPhaseFloats Emissive Intensity Over Time of Day; // 0xddc(0x10)
	float Volumetric Light Scattering Intensity; // 0xdec(0x04)
	bool Cast Volumetric Shadows; // 0xdf0(0x01)
	bool Animate Lights With A Curve - Disables time of day light controls; // 0xdf1(0x01)
	bool Animate Mesh MID Emissive Value with a Curve - Disables time of day light controls; // 0xdf2(0x01)
	char pad_DF3[0x5]; // 0xdf3(0x05)
	struct UCurveFloat* LightAnimationCurve; // 0xdf8(0x08)
	float CodeControlled_Animation Curve Animation Length; // 0xe00(0x04)
	int32_t CodeControlled_NumberOfMaterials; // 0xe04(0x04)
	struct TArray<float> NewVar_1; // 0xe08(0x10)
	float Random Time Scale Percent; // 0xe18(0x04)
	float CodeControlled_CurrentPlayLength; // 0xe1c(0x04)

	void GetTimeOfDayBlueprintDefaultVariables(struct FTimeOfDayBlueprintDefaultVariables& OutVariables); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.GetTimeOfDayBlueprintDefaultVariables // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void UserConstructionScript(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveBeginPlay(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnDayPhaseChanged(enum class EFortDayPhase CurrentDayPhase, enum class EFortDayPhase PreviousDayPhase, bool bAtCreation); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnDayPhaseChanged // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void Loop Animation Curve(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.Loop Animation Curve // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnBounceAnimationUpdate(struct FFortBounceData& Data); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnBounceAnimationUpdate // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void OnSetSearched(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnSetSearched // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_Athena_Prop_ParentBuildingContainerBlueprint(int32_t EntryPoint); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.ExecuteUbergraph_Athena_Prop_ParentBuildingContainerBlueprint // (Final|UbergraphFunction|HasDefaults) // @ game+0xd6d38c
};


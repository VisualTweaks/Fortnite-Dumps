// BlueprintGeneratedClass CurieEntityStateBehavior_ElemInteraction_Ice.CurieEntityStateBehavior_ElemInteraction_Ice_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCurieEntityStateBehavior_ElemInteraction_Ice_C : UFortCurieEntityStateBehavior {
};


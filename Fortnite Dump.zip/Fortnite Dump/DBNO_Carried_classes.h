// AnimBlueprintGeneratedClass DBNO_Carried.DBNO_Carried_C
// Size: 0x2931 (Inherited: 0x1d50)
struct UDBNO_Carried_C : UFortPlayerAnimInstance_DBNOCarried {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1d50(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x1d58(0x30)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x1d88(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0x1da8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x1eb0(0x108)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x1fb8(0x80)
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive; // 0x2038(0xc8)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK; // 0x2100(0x1e0)
	struct FAnimNode_LinkedAnimGraph AnimGraphNode_SubInstance; // 0x22e0(0xa0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x2380(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x23a0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x23c8(0x28)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_2; // 0x23f0(0x50)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x2440(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x2470(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x24f0(0x30)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator; // 0x2520(0x50)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x2570(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x25a0(0xb0)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend; // 0x2650(0xc8)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x2718(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0x2870(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x2898(0x28)
	enum class EFortPlayerAnimBodyType __CustomProperty_my_animbodytype_BC9172D64300E6A13C48509FE2988A40; // 0x28c0(0x01)
	enum class EFortCustomGender __CustomProperty_my_gender_BC9172D64300E6A13C48509FE2988A40; // 0x28c1(0x01)
	bool Carried; // 0x28c2(0x01)
	char pad_28C3[0x5]; // 0x28c3(0x05)
	struct APlayerPawn_Athena_C* CarrierPawn; // 0x28c8(0x08)
	struct UFortPlayerAnimInstance* CarrierAnimBP; // 0x28d0(0x08)
	struct FVector LHandIKLocation; // 0x28d8(0x0c)
	struct FRotator LHandIKRotation; // 0x28e4(0x0c)
	struct FVector TempAttachLocation; // 0x28f0(0x0c)
	struct FRotator TempAttachRotation; // 0x28fc(0x0c)
	float SubAnimPhysicsWeight; // 0x2908(0x04)
	bool IsBeingDropped; // 0x290c(0x01)
	char pad_290D[0x3]; // 0x290d(0x03)
	float DropMontagePosition; // 0x2910(0x04)
	char pad_2914[0x4]; // 0x2914(0x04)
	struct UAnimMontage* CarrierDropMontage; // 0x2918(0x08)
	struct UAnimMontage* CarrierPickupMontage; // 0x2920(0x08)
	bool IsBeingPickedUp; // 0x2928(0x01)
	char pad_2929[0x3]; // 0x2929(0x03)
	float PickupMontagePosition; // 0x292c(0x04)
	bool TransitionFromPickupToIdle; // 0x2930(0x01)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function DBNO_Carried.DBNO_Carried_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void EvaluateGraphExposedInputs_ExecuteUbergraph_DBNO_Carried_AnimGraphNode_ApplyAdditive_56B19EE040BEEBC25D674F8DC99831B9(); // Function DBNO_Carried.DBNO_Carried_C.EvaluateGraphExposedInputs_ExecuteUbergraph_DBNO_Carried_AnimGraphNode_ApplyAdditive_56B19EE040BEEBC25D674F8DC99831B9 // (BlueprintEvent) // @ game+0xd6d38c
	void EvaluateGraphExposedInputs_ExecuteUbergraph_DBNO_Carried_AnimGraphNode_ModifyBone_59E069244645BEF22808AB9196186F3F(); // Function DBNO_Carried.DBNO_Carried_C.EvaluateGraphExposedInputs_ExecuteUbergraph_DBNO_Carried_AnimGraphNode_ModifyBone_59E069244645BEF22808AB9196186F3F // (BlueprintEvent) // @ game+0xd6d38c
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function DBNO_Carried.DBNO_Carried_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void BlueprintInitializeAnimation(); // Function DBNO_Carried.DBNO_Carried_C.BlueprintInitializeAnimation // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_DBNO_Carried(int32_t EntryPoint); // Function DBNO_Carried.DBNO_Carried_C.ExecuteUbergraph_DBNO_Carried // (Final|UbergraphFunction|HasDefaults) // @ game+0xd6d38c
};


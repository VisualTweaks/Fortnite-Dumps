// BlueprintGeneratedClass ButtonStyle-Skew_LDarkBlue.ButtonStyle-Skew_LDarkBlue_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Skew_LDarkBlue_C : UCommonButtonStyle {
};


// UserDefinedEnum Enum_BoostJumpStates.Enum_BoostJumpStates
enum class Enum_BoostJumpStates : uint8 {
	NewEnumerator3 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator4 = 4,
	Enum_MAX = 5
};


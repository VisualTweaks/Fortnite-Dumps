// BlueprintGeneratedClass Athena_ButtonStyle_AngledBlueMenuButton.Athena_ButtonStyle_AngledBlueMenuButton_C
// Size: 0x570 (Inherited: 0x570)
struct UAthena_ButtonStyle_AngledBlueMenuButton_C : UCommonButtonStyle {
};


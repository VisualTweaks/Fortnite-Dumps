// BlueprintGeneratedClass BP_SprayDecal.BP_SprayDecal_C
// Size: 0xd3e (Inherited: 0xc88)
struct ABP_SprayDecal_C : AFortSprayDecalInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc88(0x08)
	float DecalFadeoutTime; // 0xc90(0x04)
	char pad_C94[0x4]; // 0xc94(0x04)
	struct UDecalComponent* EmissiveDecal; // 0xc98(0x08)
	struct UMaterialInstanceDynamic* EmissiveDecalMID; // 0xca0(0x08)
	float DecalSize; // 0xca8(0x04)
	char pad_CAC[0x4]; // 0xcac(0x04)
	struct UMaterialInterface* EmissiveMatSource; // 0xcb0(0x08)
	float DecalDepth; // 0xcb8(0x04)
	char pad_CBC[0x4]; // 0xcbc(0x04)
	struct UAthenaSprayItemDefinition* SprayAsset; // 0xcc0(0x08)
	int32_t LoadsOutstanding; // 0xcc8(0x04)
	char pad_CCC[0x4]; // 0xccc(0x04)
	struct TSoftObjectPtr<UTexture2D> DecalTextureOverrideSoft; // 0xcd0(0x28)
	struct UTexture2D* DecalTextureOverride; // 0xcf8(0x08)
	struct FLinearColor BannerPrimaryColor; // 0xd00(0x10)
	struct FLinearColor BannerSecondaryColor; // 0xd10(0x10)
	struct AFortPlayerController* SpawningPlayerController; // 0xd20(0x08)
	struct TArray<struct AActor*> NearbyBuildingActors; // 0xd28(0x10)
	float SpawnStartTimeDelay; // 0xd38(0x04)
	bool bIsFrontEndPreview; // 0xd3c(0x01)
	bool bDestroyOnTrapPlaced; // 0xd3d(0x01)

	void AddBoxCollisionForCreative(); // Function BP_SprayDecal.BP_SprayDecal_C.AddBoxCollisionForCreative // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void FindNearbyBuildingActorsAndBindDelegates(); // Function BP_SprayDecal.BP_SprayDecal_C.FindNearbyBuildingActorsAndBindDelegates // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void UnbindAndClearNearbyBuildingActors(); // Function BP_SprayDecal.BP_SprayDecal_C.UnbindAndClearNearbyBuildingActors // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnRep_DecalFadeoutTime(); // Function BP_SprayDecal.BP_SprayDecal_C.OnRep_DecalFadeoutTime // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	struct FUniqueNetIdRepl GetInstigatorPlayerId(); // Function BP_SprayDecal.BP_SprayDecal_C.GetInstigatorPlayerId // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void CreateDecalComponents(); // Function BP_SprayDecal.BP_SprayDecal_C.CreateDecalComponents // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void UserConstructionScript(); // Function BP_SprayDecal.BP_SprayDecal_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnLoaded_F8AB699B4D8DD22B5A0409B608B7D6FA(struct UObject* Loaded); // Function BP_SprayDecal.BP_SprayDecal_C.OnLoaded_F8AB699B4D8DD22B5A0409B608B7D6FA // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnLoaded_F925FF00475A018319C73E9FB1540BC6(struct UObject* Loaded); // Function BP_SprayDecal.BP_SprayDecal_C.OnLoaded_F925FF00475A018319C73E9FB1540BC6 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnReady_B252FED346EAB98D54D786BD15C1CC7B(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer& PlaylistContextTags); // Function BP_SprayDecal.BP_SprayDecal_C.OnReady_B252FED346EAB98D54D786BD15C1CC7B // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveBeginPlay(); // Function BP_SprayDecal.BP_SprayDecal_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnSprayAssetReplicatedDown(); // Function BP_SprayDecal.BP_SprayDecal_C.OnSprayAssetReplicatedDown // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnSprayInfoReady(); // Function BP_SprayDecal.BP_SprayDecal_C.OnSprayInfoReady // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void StartSprayFadeOutDueToNewPlacement(); // Function BP_SprayDecal.BP_SprayDecal_C.StartSprayFadeOutDueToNewPlacement // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnNearbyWallDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BP_SprayDecal.BP_SprayDecal_C.OnNearbyWallDied // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnNearbyWallDamaged(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BP_SprayDecal.BP_SprayDecal_C.OnNearbyWallDamaged // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnBounceOccurs(); // Function BP_SprayDecal.BP_SprayDecal_C.OnBounceOccurs // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnNearbyTrapPlaced(struct ABuildingTrap* Trap, bool bDetatched); // Function BP_SprayDecal.BP_SprayDecal_C.OnNearbyTrapPlaced // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void PostLevelSaveSpawnCleanup(); // Function BP_SprayDecal.BP_SprayDecal_C.PostLevelSaveSpawnCleanup // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnWallDestoryed(struct AActor* DestroyedActor); // Function BP_SprayDecal.BP_SprayDecal_C.OnWallDestoryed // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_BP_SprayDecal(int32_t EntryPoint); // Function BP_SprayDecal.BP_SprayDecal_C.ExecuteUbergraph_BP_SprayDecal // (Final|UbergraphFunction|HasDefaults) // @ game+0xd6d38c
};


// Class DiscordRPC.DiscordRuntimeSettings
// Size: 0x30 (Inherited: 0x28)
struct UDiscordRuntimeSettings : UObject {
	bool bEnableJoinSecrets; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};


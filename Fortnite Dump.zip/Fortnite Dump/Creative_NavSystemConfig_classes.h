// BlueprintGeneratedClass Creative_NavSystemConfig.Creative_NavSystemConfig_C
// Size: 0x230 (Inherited: 0x230)
struct ACreative_NavSystemConfig_C : AAthenaNavSystemConfigOverride {
};


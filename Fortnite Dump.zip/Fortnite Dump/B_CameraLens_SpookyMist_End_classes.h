// BlueprintGeneratedClass B_CameraLens_SpookyMist_End.B_CameraLens_SpookyMist_End_C
// Size: 0x2e8 (Inherited: 0x2e0)
struct AB_CameraLens_SpookyMist_End_C : AEmitterCameraLensEffectBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e0(0x08)

	void ReceiveBeginPlay(); // Function B_CameraLens_SpookyMist_End.B_CameraLens_SpookyMist_End_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_B_CameraLens_SpookyMist_End(int32_t EntryPoint); // Function B_CameraLens_SpookyMist_End.B_CameraLens_SpookyMist_End_C.ExecuteUbergraph_B_CameraLens_SpookyMist_End // (Final|UbergraphFunction) // @ game+0xd6d38c
};


// BlueprintGeneratedClass AthenaDanceItemDefinition_AdHocSquadsJoin.AthenaDanceItemDefinition_AdHocSquadsJoin_C
// Size: 0x928 (Inherited: 0x908)
struct UAthenaDanceItemDefinition_AdHocSquadsJoin_C : UAthenaDanceItemDefinition {
	struct UAthenaDanceItemDefinition* GroupEmoteToStartLeader_AutoSquadUp; // 0x908(0x08)
	struct UAthenaDanceItemDefinition* GroupEmoteToStartFollower_AdHocSquadUp; // 0x910(0x08)
	struct UAthenaDanceItemDefinition* GroupEmoteToStartLeaderIfBothOwn_AdHocSquadUp; // 0x918(0x08)
	struct UAthenaDanceItemDefinition* GroupEmoteToStartFollowerIfBothOwn_AdHocSquadUp; // 0x920(0x08)
};


// Class F5PlayerFactory.F5PlayerFactorySettings
// Size: 0x28 (Inherited: 0x28)
struct UF5PlayerFactorySettings : UObject {
};


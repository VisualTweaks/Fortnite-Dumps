// BlueprintGeneratedClass Athena_PlayerCameraMode_RespawnedAir.Athena_PlayerCameraMode_RespawnedAir_C
// Size: 0xde0 (Inherited: 0xde0)
struct UAthena_PlayerCameraMode_RespawnedAir_C : UFortCameraMode_RespawnedAir {
};


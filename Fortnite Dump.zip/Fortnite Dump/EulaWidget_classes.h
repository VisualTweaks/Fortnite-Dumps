// WidgetBlueprintGeneratedClass EulaWidget.EulaWidget_C
// Size: 0x4d0 (Inherited: 0x4c0)
struct UEulaWidget_C : UFortEulaWidget {
	struct FMulticastInlineDelegate OnEulaResponse; // 0x4c0(0x10)

	void OnEulaResponse__DelegateSignature(bool Accepted); // Function EulaWidget.EulaWidget_C.OnEulaResponse__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
};


// BlueprintGeneratedClass CommonUI_GenericBrushData.CommonUI_GenericBrushData_C
// Size: 0xd0 (Inherited: 0xd0)
struct UCommonUI_GenericBrushData_C : UFortInputControllerData {
};


// BlueprintGeneratedClass CinematicCamera_MatineeTransition.CinematicCamera_MatineeTransition_C
// Size: 0x60 (Inherited: 0x60)
struct UCinematicCamera_MatineeTransition_C : UFortCinematicCamera {
};


// Enum DLSSBlueprint.UDLSSMode
enum class UDLSSMode : uint8 {
	Off = 0,
	UltraPerformance = 1,
	Performance = 2,
	Balanced = 3,
	Quality = 4,
	UltraQuality = 5,
	UDLSSMode_MAX = 6
};

// Enum DLSSBlueprint.UDLSSSupport
enum class UDLSSSupport : uint8 {
	Supported = 0,
	NotSupported = 1,
	NotSupportedIncompatibleHardware = 2,
	NotSupportedDriverOutOfDate = 3,
	NotSupportedOperatingSystemOutOfDate = 4,
	UDLSSSupport_MAX = 5
};


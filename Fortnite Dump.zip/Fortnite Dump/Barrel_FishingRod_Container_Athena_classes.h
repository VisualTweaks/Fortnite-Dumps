// BlueprintGeneratedClass Barrel_FishingRod_Container_Athena.Barrel_FishingRod_Container_Athena_C
// Size: 0xf29 (Inherited: 0xf29)
struct ABarrel_FishingRod_Container_Athena_C : AHotfix_Container_Parent_C {
};


// BlueprintGeneratedClass Border_Solid_MdBlue.Border_Solid_MdBlue_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_Solid_MdBlue_C : UBorder-TabM_C {
};


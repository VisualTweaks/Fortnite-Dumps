// BlueprintGeneratedClass B_HidingProp.B_HidingProp_C
// Size: 0x10b9 (Inherited: 0xd40)
struct AB_HidingProp_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd40(0x08)
	struct USceneComponent* ProjectileLocation_ForwardVector; // 0xd48(0x08)
	struct UStaticMeshComponent* LandedOnCollisionMesh; // 0xd50(0x08)
	struct USphereComponent* Sphere; // 0xd58(0x08)
	struct USceneComponent* HideLocation_ForwardVector; // 0xd60(0x08)
	float Loot_MovementTimeline_Forward_0FC694AE4A45D691CB6BD5A8CD00E521; // 0xd68(0x04)
	float Loot_MovementTimeline_Z_0FC694AE4A45D691CB6BD5A8CD00E521; // 0xd6c(0x04)
	enum class ETimelineDirection Loot_MovementTimeline__Direction_0FC694AE4A45D691CB6BD5A8CD00E521; // 0xd70(0x01)
	char pad_D71[0x7]; // 0xd71(0x07)
	struct UTimelineComponent* Loot_MovementTimeline; // 0xd78(0x08)
	struct FScalableFloat Enabled; // 0xd80(0x28)
	struct FScalableFloat HidingEnabled; // 0xda8(0x28)
	struct FScalableFloat PlayerLimit; // 0xdd0(0x28)
	struct FScalableFloat TeleportEnabled; // 0xdf8(0x28)
	struct FScalableFloat CanTeleport; // 0xe20(0x28)
	struct TArray<struct AFortPawn*> HidingPlayers; // 0xe48(0x10)
	struct FGameplayTag EnterGameplayCue; // 0xe58(0x08)
	struct FGameplayTag ExitGameplayCue; // 0xe60(0x08)
	struct FGameplayTag LandedOnGameplayCue; // 0xe68(0x08)
	struct UMaterialInstanceDynamic* Mid; // 0xe70(0x08)
	struct FGameplayTag RustleGameplayCue; // 0xe78(0x08)
	struct FGameplayTag ExitGameplayCue_Player; // 0xe80(0x08)
	struct FGameplayTag WhileEnteringGameplayCue; // 0xe88(0x08)
	float ObstructionTraceLength; // 0xe90(0x04)
	char pad_E94[0x4]; // 0xe94(0x04)
	struct TArray<enum class EObjectTypeQuery> DestroyObjectTypes; // 0xe98(0x10)
	struct TArray<struct AFortPawn*> Array; // 0xea8(0x10)
	int32_t Int; // 0xeb8(0x04)
	struct FVector DeimosPropSpawnerOffset; // 0xebc(0x0c)
	bool FixedEntranceDirection; // 0xec8(0x01)
	char pad_EC9[0x3]; // 0xec9(0x03)
	float MaxInteractAngle; // 0xecc(0x04)
	struct FVector WobbleLocationOffset; // 0xed0(0x0c)
	float InteractBelowPropDistance; // 0xedc(0x04)
	struct TMap<struct AFortPawn*, float> HiddenPlayersAndEnterTimes; // 0xee0(0x50)
	struct AFortPawn* LastPawnToInteract; // 0xf30(0x08)
	struct AB_HidingProp_C* TargetTeleporter; // 0xf38(0x08)
	struct FGameplayTag TeleporterEnterGameplayCue; // 0xf40(0x08)
	struct FGameplayTag TeleporterExitGameplayCue; // 0xf48(0x08)
	struct FGameplayTag LoopingTeleportingCue; // 0xf50(0x08)
	struct FGameplayTag GC_Wobble; // 0xf58(0x08)
	struct FTimerHandle WobbleTimerHandle; // 0xf60(0x08)
	struct TArray<struct FGameplayTag> BlockEntranceTags; // 0xf68(0x10)
	struct TArray<struct FGameplayTag> BlockExitTags; // 0xf78(0x10)
	struct UAnimMontage* EnterAnimMontage; // 0xf88(0x08)
	struct UAnimMontage* ExitAnimMontage; // 0xf90(0x08)
	struct AFortPawn* LastPawnToHide; // 0xf98(0x08)
	struct FGameplayTag TeleportingStateGC; // 0xfa0(0x08)
	bool RandomWobbleNormal; // 0xfa8(0x01)
	bool SingleOccupant; // 0xfa9(0x01)
	bool Teleporting; // 0xfaa(0x01)
	bool JumpOut; // 0xfab(0x01)
	bool DestroyInNonSpyLTM; // 0xfac(0x01)
	bool ActiveInSpyLTM; // 0xfad(0x01)
	char pad_FAE[0x2]; // 0xfae(0x02)
	struct TArray<struct FGameplayTag> ForceAllowInteractTags; // 0xfb0(0x10)
	struct FGameplayTag IsTeleporter; // 0xfc0(0x08)
	struct FGameplayTag ContainsPlayerRepNof; // 0xfc8(0x08)
	struct FVector ObstructionTraceExtents; // 0xfd0(0x0c)
	struct FVector ObstructionTraceStartOffSet; // 0xfdc(0x0c)
	float ExitLaunchVelocity; // 0xfe8(0x04)
	struct FVector AdditionalLaunchVelocity; // 0xfec(0x0c)
	struct FVector FixedEntraceObstructionTraceEndOffset; // 0xff8(0x0c)
	bool isActiveTeleportExit; // 0x1004(0x01)
	char pad_1005[0x3]; // 0x1005(0x03)
	struct UGameplayEffect* GE_TeleportAbilityGranted; // 0x1008(0x08)
	bool DisableWhenSubmergedInWater; // 0x1010(0x01)
	char pad_1011[0x7]; // 0x1011(0x07)
	struct FGameplayTagContainer DisableWhenSubmergedExceptionTags; // 0x1018(0x20)
	struct TArray<struct AFortPawn*> NonCosmeticPawns; // 0x1038(0x10)
	struct UCameraModifier* CameraModifier; // 0x1048(0x08)
	struct FVector NewVar_1; // 0x1050(0x0c)
	char pad_105C[0x4]; // 0x105c(0x04)
	struct AActor* Pawn; // 0x1060(0x08)
	struct FVector Loot_CachedActorForward; // 0x1068(0x0c)
	char pad_1074[0x4]; // 0x1074(0x04)
	struct TArray<struct FVector> Loot_VectorOffsets; // 0x1078(0x10)
	bool SpawnedLoot; // 0x1088(0x01)
	char pad_1089[0x3]; // 0x1089(0x03)
	float Loot_MoveForwardDistance; // 0x108c(0x04)
	float Loot_MoveUpDistance; // 0x1090(0x04)
	float Loot_SpawnRadius; // 0x1094(0x04)
	struct FVector Loot_SpawnOffset; // 0x1098(0x0c)
	bool ShouldSpawnLoot; // 0x10a4(0x01)
	char pad_10A5[0x3]; // 0x10a5(0x03)
	struct FString Loot Tier Group; // 0x10a8(0x10)
	bool SetEntranceRotation; // 0x10b8(0x01)

	void Allow Cosmetics For Pawn(struct AFortPawn*& Pawn, bool& Allow); // Function B_HidingProp.B_HidingProp_C.Allow Cosmetics For Pawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnRep_ContainsPlayer(); // Function B_HidingProp.B_HidingProp_C.OnRep_ContainsPlayer // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnRep_IsTeleporter(); // Function B_HidingProp.B_HidingProp_C.OnRep_IsTeleporter // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	bool CheckCanUsePassage(struct UObject* Object); // Function B_HidingProp.B_HidingProp_C.CheckCanUsePassage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	bool IsInInfiltrationLTM(); // Function B_HidingProp.B_HidingProp_C.IsInInfiltrationLTM // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xd6d38c
	void OnRep_Teleporting(); // Function B_HidingProp.B_HidingProp_C.OnRep_Teleporting // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	struct FText BlueprintGetFailedInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintGetFailedInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xd6d38c
	void RemoveHiddenPlayer(struct AFortPawn* FortPawn); // Function B_HidingProp.B_HidingProp_C.RemoveHiddenPlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void AddHiddenPlayer(struct AFortPawn* FortPawn); // Function B_HidingProp.B_HidingProp_C.AddHiddenPlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnRep_HidingPlayers(); // Function B_HidingProp.B_HidingProp_C.OnRep_HidingPlayers // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float& OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xd6d38c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xd6d38c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function B_HidingProp.B_HidingProp_C.BlueprintCanInteract // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xd6d38c
	void Loot_MovementTimeline__FinishedFunc(); // Function B_HidingProp.B_HidingProp_C.Loot_MovementTimeline__FinishedFunc // (BlueprintEvent) // @ game+0xd6d38c
	void Loot_MovementTimeline__UpdateFunc(); // Function B_HidingProp.B_HidingProp_C.Loot_MovementTimeline__UpdateFunc // (BlueprintEvent) // @ game+0xd6d38c
	void OnReady_64CBF02E419FF250B433D5B2A6E5D744(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer& PlaylistContextTags); // Function B_HidingProp.B_HidingProp_C.OnReady_64CBF02E419FF250B433D5B2A6E5D744 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnCurieActive_F2BFC8C54691C42FB5230BA7B7DEE141(); // Function B_HidingProp.B_HidingProp_C.OnCurieActive_F2BFC8C54691C42FB5230BA7B7DEE141 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnDeathServer(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function B_HidingProp.B_HidingProp_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void BndEvt__S_Athena_Launchpad_Collision_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function B_HidingProp.B_HidingProp_C.BndEvt__S_Athena_Launchpad_Collision_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void LandedOnHayStack(struct AFortPlayerPawn* PlayerPawn, float Z Velocity Mag); // Function B_HidingProp.B_HidingProp_C.LandedOnHayStack // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void LaunchPlayersOffTop(struct AFortPlayerPawn* PlayerPawn); // Function B_HidingProp.B_HidingProp_C.LaunchPlayersOffTop // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveActorBeginOverlap(struct AActor* OtherActor); // Function B_HidingProp.B_HidingProp_C.ReceiveActorBeginOverlap // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void StopHidingLoop(); // Function B_HidingProp.B_HidingProp_C.StopHidingLoop // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void HidingPlayerCountChanged(); // Function B_HidingProp.B_HidingProp_C.HidingPlayerCountChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void InteractEnter(); // Function B_HidingProp.B_HidingProp_C.InteractEnter // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void EndHidingAnalyticSession(struct AFortPawn* FortPawn, enum class EEnvironmentalItemEndReason EndReason); // Function B_HidingProp.B_HidingProp_C.EndHidingAnalyticSession // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void WatchForPlayerDeath(struct AFortPawn* FortPawn); // Function B_HidingProp.B_HidingProp_C.WatchForPlayerDeath // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Pawn Died(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function B_HidingProp.B_HidingProp_C.Pawn Died // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void StopHiding(struct AFortPawn* Pawn); // Function B_HidingProp.B_HidingProp_C.StopHiding // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveBeginPlay(); // Function B_HidingProp.B_HidingProp_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void Teleport(struct AActor* Pawn); // Function B_HidingProp.B_HidingProp_C.Teleport // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void IgnorePawnCollision(struct AFortPawn* Target, float InIgnoreDuration); // Function B_HidingProp.B_HidingProp_C.IgnorePawnCollision // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ToggleCameraCollisionForClients(); // Function B_HidingProp.B_HidingProp_C.ToggleCameraCollisionForClients // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void StartHiding(struct AFortPawn* InteractingPawn); // Function B_HidingProp.B_HidingProp_C.StartHiding // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void TurnClientCameraCollisionOn(); // Function B_HidingProp.B_HidingProp_C.TurnClientCameraCollisionOn // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void AddGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& CueParameters); // Function B_HidingProp.B_HidingProp_C.AddGameplayCue // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void RemoveGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& CueParameters); // Function B_HidingProp.B_HidingProp_C.RemoveGameplayCue // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& CueParameters); // Function B_HidingProp.B_HidingProp_C.ExecuteGameplayCue // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnMatchStarted(); // Function B_HidingProp.B_HidingProp_C.OnMatchStarted // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void Launch Pickups(struct TArray<struct AFortPickup*>& Array, struct AActor* Pawn); // Function B_HidingProp.B_HidingProp_C.Launch Pickups // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_B_HidingProp(int32_t EntryPoint); // Function B_HidingProp.B_HidingProp_C.ExecuteUbergraph_B_HidingProp // (Final|UbergraphFunction|HasDefaults) // @ game+0xd6d38c
};


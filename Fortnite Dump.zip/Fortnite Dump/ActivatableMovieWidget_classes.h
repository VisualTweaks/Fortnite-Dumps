// WidgetBlueprintGeneratedClass ActivatableMovieWidget.ActivatableMovieWidget_C
// Size: 0x5b0 (Inherited: 0x5a0)
struct UActivatableMovieWidget_C : UFortActivatableVideoPanel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5a0(0x08)
	struct USafeZone* MainSafeZone; // 0x5a8(0x08)

	void Construct(); // Function ActivatableMovieWidget.ActivatableMovieWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_ActivatableMovieWidget(int32_t EntryPoint); // Function ActivatableMovieWidget.ActivatableMovieWidget_C.ExecuteUbergraph_ActivatableMovieWidget // (Final|UbergraphFunction) // @ game+0xd6d38c
};


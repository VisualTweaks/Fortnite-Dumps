// BlueprintGeneratedClass B_HidingProp_WilliePete.B_HidingProp_WilliePete_C
// Size: 0x1282 (Inherited: 0x10b9)
struct AB_HidingProp_WilliePete_C : AB_HidingProp_C {
	char pad_10B9[0x7]; // 0x10b9(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x10c0(0x08)
	struct UStaticMeshComponent* overlapCylinder; // 0x10c8(0x08)
	struct UAudioComponent* WilliePete_Ambient_Loop; // 0x10d0(0x08)
	struct UStaticMeshComponent* Geyser; // 0x10d8(0x08)
	struct UStaticMeshComponent* S_Whirlpool_01; // 0x10e0(0x08)
	struct UParticleSystemComponent* P_WilliePete_SurfaceVerticalSplash; // 0x10e8(0x08)
	struct UFortProjectileMovementComponent* OverlappedFortProjectileMovementComponent; // 0x10f0(0x08)
	struct UProjectileMovementComponent* OverlappedStandardProjectileMovementComponent; // 0x10f8(0x08)
	struct AActor* TeleportingNonPawn; // 0x1100(0x08)
	struct FHitResult SphereOverlapResult; // 0x1108(0x88)
	float ProjectileSpeedCeiling; // 0x1190(0x04)
	struct FRotator ProjectileExitFVectorRotation; // 0x1194(0x0c)
	int32_t WaterLevel; // 0x11a0(0x04)
	struct FGameplayTag GC_Exit; // 0x11a4(0x08)
	struct FGameplayTag GC_Enter; // 0x11ac(0x08)
	char pad_11B4[0x4]; // 0x11b4(0x04)
	struct FScalableFloat EnabledValue; // 0x11b8(0x28)
	struct FScalableFloat LaunchHeightValue; // 0x11e0(0x28)
	struct AFortPlayerPawnAthena* LaunchPawn; // 0x1208(0x08)
	struct FActiveGameplayEffectHandle LaunchGrantedEffectHandle; // 0x1210(0x08)
	struct FGameplayTagContainer T_Quest; // 0x1218(0x20)
	struct AActor* SpawnedWaterBody; // 0x1238(0x08)
	struct FGameplayTag GC_ScreenFX; // 0x1240(0x08)
	bool isOnTestMap; // 0x1248(0x01)
	char pad_1249[0x7]; // 0x1249(0x07)
	struct USoundBase* Launch Sound; // 0x1250(0x08)
	struct FVector AdjustedLocation; // 0x1258(0x0c)
	bool skipAnimForLaunch; // 0x1264(0x01)
	char pad_1265[0x3]; // 0x1265(0x03)
	struct AFortPlayerPawnAthena* ExitingPawn; // 0x1268(0x08)
	struct UMovementComponent* OverlappedMovementComponent; // 0x1270(0x08)
	float ProjectileSpeedMult; // 0x1278(0x04)
	float PickupSpeedMult; // 0x127c(0x04)
	bool bSetSilentDie; // 0x1280(0x01)
	bool bSetSpawnedWaterBody; // 0x1281(0x01)

	void OnRep_bSetSpawnedWaterBody(); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.OnRep_bSetSpawnedWaterBody // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnRep_bSetSilentDie(); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.OnRep_bSetSilentDie // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void HelperLocationLogger(struct FString inString); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.HelperLocationLogger // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnRep_AdjustedLocation(); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.OnRep_AdjustedLocation // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void TeleportExitSpeed(struct FVector ExitFVector, float EnterSpeed, float OverrideSpeed, float MinimumSpeed, bool ForceSpeedOverride, struct FVector& TeleportExitVelocity); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.TeleportExitSpeed // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xd6d38c
	void OnReady_74044DD44988556292500EB8F289359F(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer& PlaylistContextTags); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.OnReady_74044DD44988556292500EB8F289359F // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Non Pawn Actor Destroyed(struct AActor* DestroyedActor); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.Non Pawn Actor Destroyed // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Non Pawn Teleport(struct AActor* TeleportingActor); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.Non Pawn Teleport // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveBeginPlay(); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void Remove GE(); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.Remove GE // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void BndEvt__overlapCylinder_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.BndEvt__overlapCylinder_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void Complete Setup(); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.Complete Setup // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void StopHiding(struct AFortPawn* Pawn); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.StopHiding // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ResetGravity(struct FHitResult& Hit); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.ResetGravity // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_B_HidingProp_WilliePete(int32_t EntryPoint); // Function B_HidingProp_WilliePete.B_HidingProp_WilliePete_C.ExecuteUbergraph_B_HidingProp_WilliePete // (Final|UbergraphFunction|HasDefaults) // @ game+0xd6d38c
};


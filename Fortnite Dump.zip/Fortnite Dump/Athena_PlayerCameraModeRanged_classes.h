// BlueprintGeneratedClass Athena_PlayerCameraModeRanged.Athena_PlayerCameraModeRanged_C
// Size: 0xde0 (Inherited: 0xde0)
struct UAthena_PlayerCameraModeRanged_C : UAthena_PlayerCameraModeBase_C {
};


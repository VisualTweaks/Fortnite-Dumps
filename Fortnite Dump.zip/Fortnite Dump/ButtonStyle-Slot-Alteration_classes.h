// BlueprintGeneratedClass ButtonStyle-Slot-Alteration.ButtonStyle-Slot-Alteration_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Slot-Alteration_C : UCommonButtonStyle {
};


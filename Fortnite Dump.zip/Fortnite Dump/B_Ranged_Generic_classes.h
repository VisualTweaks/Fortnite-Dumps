// BlueprintGeneratedClass B_Ranged_Generic.B_Ranged_Generic_C
// Size: 0x1a50 (Inherited: 0x1800)
struct AB_Ranged_Generic_C : AFortWeaponRanged {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1800(0x08)
	struct UParticleSystemComponent* Reload(Empty); // 0x1808(0x08)
	struct UStaticMeshComponent* ScopeMesh1P; // 0x1810(0x08)
	struct UParticleSystemComponent* Muzzle(Empty); // 0x1818(0x08)
	float AnimateScopePostProcess_DownSightPostProcessAmount_393D8BA5486879173797EF8C9B8D4642; // 0x1820(0x04)
	enum class ETimelineDirection AnimateScopePostProcess__Direction_393D8BA5486879173797EF8C9B8D4642; // 0x1824(0x01)
	char pad_1825[0x3]; // 0x1825(0x03)
	struct UTimelineComponent* AnimateScopePostProcess; // 0x1828(0x08)
	struct UParticleSystem* MuzzleParticleSystem; // 0x1830(0x08)
	struct UParticleSystem* WeaponDurabilityDestroyEffect; // 0x1838(0x08)
	struct UParticleSystem* WeaponDurabilityDestroyEffectIcon; // 0x1840(0x08)
	bool UseDestroyEffect; // 0x1848(0x01)
	bool Use Reload Particles; // 0x1849(0x01)
	char pad_184A[0x6]; // 0x184a(0x06)
	struct UParticleSystem* Reload_ParticleSystem; // 0x1850(0x08)
	float LastPlayFXTime; // 0x1858(0x04)
	float MinPlayFXTime; // 0x185c(0x04)
	bool UseShellsOnFire?; // 0x1860(0x01)
	bool UseShellsOnReload?; // 0x1861(0x01)
	bool UseShellsOnPump?; // 0x1862(0x01)
	char pad_1863[0x1]; // 0x1863(0x01)
	struct FName ReloadSocketName; // 0x1864(0x08)
	char pad_186C[0x4]; // 0x186c(0x04)
	struct TArray<struct AFortAIPawn*> Array Of Active Enemy AI; // 0x1870(0x10)
	bool Scope - Render Enemies To Custom Depth Buffer; // 0x1880(0x01)
	char pad_1881[0x3]; // 0x1881(0x03)
	struct FName Shells Socket Name; // 0x1884(0x08)
	enum class En_ShellTypes_01 ShellTypeSelect; // 0x188c(0x01)
	char pad_188D[0x3]; // 0x188d(0x03)
	float Shells Spawn Rate Scale; // 0x1890(0x04)
	struct FVector ShellsRotationRate; // 0x1894(0x0c)
	struct FVector Shells Velocity; // 0x18a0(0x0c)
	struct FVector Shells Gravity; // 0x18ac(0x0c)
	struct FVector Shells Size; // 0x18b8(0x0c)
	float Target Scope Vignette Blur Screen Percentage; // 0x18c4(0x04)
	float Scope Camera Offset Amount; // 0x18c8(0x04)
	float Inherit Parent Velocity; // 0x18cc(0x04)
	float Cylindrical Radius; // 0x18d0(0x04)
	float Cylindrical Height; // 0x18d4(0x04)
	struct FLinearColor Shell Color; // 0x18d8(0x10)
	struct UNiagaraComponent* Spawned_Shells; // 0x18e8(0x08)
	bool DebugShellsSocket?; // 0x18f0(0x01)
	char pad_18F1[0x7]; // 0x18f1(0x07)
	struct USoundBase* Sound_ScopeZoomIn; // 0x18f8(0x08)
	struct USoundBase* Sound_ScopeZoomOut; // 0x1900(0x08)
	struct UParticleSystemComponent* Alteration Ambient PS; // 0x1908(0x08)
	struct FGameplayTagContainer ReticleHUDElementTags; // 0x1910(0x20)
	bool Is Wind Enabled; // 0x1930(0x01)
	char pad_1931[0x7]; // 0x1931(0x07)
	struct UParticleSystem* MuzzleWindParticleSystem; // 0x1938(0x08)
	struct UParticleSystem* MuzzleParticleSystem1P; // 0x1940(0x08)
	bool ShouldHideReticleAfterDelay; // 0x1948(0x01)
	char pad_1949[0x7]; // 0x1949(0x07)
	struct UParticleSystemComponent* MuzzleWindParticleSpawned; // 0x1950(0x08)
	int32_t StencilBufferValue; // 0x1958(0x04)
	char pad_195C[0x4]; // 0x195c(0x04)
	struct UCurveFloat* Curve_PitchOffset; // 0x1960(0x08)
	struct USoundBase* Sound_ScopedInLoop; // 0x1968(0x08)
	struct UAudioComponent* ScopeZoomInComp; // 0x1970(0x08)
	struct UAudioComponent* ScopedInLoopComp; // 0x1978(0x08)
	struct UAudioComponent* ScopeZoomOutComp; // 0x1980(0x08)
	float Alteration Ambient PS Max Draw Distance; // 0x1988(0x04)
	float Muzzle PS Max Draw Distance; // 0x198c(0x04)
	float Beam PS Max Draw Distance; // 0x1990(0x04)
	float Reload PS Max Draw Distance; // 0x1994(0x04)
	float Shells PS Max Draw Distance; // 0x1998(0x04)
	char pad_199C[0x4]; // 0x199c(0x04)
	struct FMulticastInlineDelegate onAimDownSightsChanged; // 0x19a0(0x10)
	bool IsMuzzleNiagara; // 0x19b0(0x01)
	char pad_19B1[0x7]; // 0x19b1(0x07)
	struct UNiagaraSystem* MuzzleNiagaraSystemInstance; // 0x19b8(0x08)
	struct TSoftObjectPtr<UNiagaraSystem> MuzzleNiagaraSystemAsset; // 0x19c0(0x28)
	struct UNiagaraComponent* MuzzleNiagaraComponentInstance; // 0x19e8(0x08)
	struct TArray<struct UParticleSystemComponent*> MuzzleParticleSystemComponents; // 0x19f0(0x10)
	float Muzzle_ChanceOfLargeFlash; // 0x1a00(0x04)
	float Muzzle_FlashLarge_MinScale; // 0x1a04(0x04)
	float Muzzle_FlashLarge_MaxScale; // 0x1a08(0x04)
	float Muzzle_FlashSmall_MinScale; // 0x1a0c(0x04)
	float Muzzle_FlashSmall_MaxScale; // 0x1a10(0x04)
	char pad_1A14[0x4]; // 0x1a14(0x04)
	struct FTimerHandle ScopeEffectDelay1Handle; // 0x1a18(0x08)
	struct FTimerHandle ScopeEffectDelay2Handle; // 0x1a20(0x08)
	struct FScalableFloat UseNativeFX; // 0x1a28(0x28)

	void GetCorrectMuzzleNiagaraSystem(struct TSoftObjectPtr<UNiagaraSystem>& OutNiagaraSystem); // Function B_Ranged_Generic.B_Ranged_Generic_C.GetCorrectMuzzleNiagaraSystem // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xd6d38c
	void PlayScopeOutAudio(); // Function B_Ranged_Generic.B_Ranged_Generic_C.PlayScopeOutAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void GetScopeParameters(struct UStaticMeshComponent*& ScopeComponent, struct FVector2D& DepthOfFieldVignetteRange, float& WeaponSightsCameraOffset); // Function B_Ranged_Generic.B_Ranged_Generic_C.GetScopeParameters // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void GetActiveMuzzleComponents(struct TArray<struct UFXSystemComponent*>& NewParam); // Function B_Ranged_Generic.B_Ranged_Generic_C.GetActiveMuzzleComponents // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xd6d38c
	void SetActiveMuzzleComponent(bool NiagaraEnabled); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetActiveMuzzleComponent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void StopScopedAudio(); // Function B_Ranged_Generic.B_Ranged_Generic_C.StopScopedAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void StartScopedAudio(); // Function B_Ranged_Generic.B_Ranged_Generic_C.StartScopedAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SetPostProcessParams(float InputPin); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetPostProcessParams // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SetActiveAlterationIdleParticles(bool Active); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetActiveAlterationIdleParticles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ShowReticle(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShowReticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void HideReticle(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideReticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ActivateOrDeactivateWindParticle(bool bNewActive); // Function B_Ranged_Generic.B_Ranged_Generic_C.ActivateOrDeactivateWindParticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void DeactivateMuzzleFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.DeactivateMuzzleFX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void DeactivateReloadSmokeFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.DeactivateReloadSmokeFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ActivateReloadSmokeFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ActivateReloadSmokeFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ActivateShellsFX(bool Bool); // Function B_Ranged_Generic.B_Ranged_Generic_C.ActivateShellsFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void DeactivateShellsFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.DeactivateShellsFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SetupShellFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetupShellFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void UpdateShellEmittersFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UpdateShellEmittersFX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Muzzle Play Reload FX(enum class EFortReloadFXState Selection); // Function B_Ranged_Generic.B_Ranged_Generic_C.Muzzle Play Reload FX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Muzzle Flash FX(bool Persistent Fire); // Function B_Ranged_Generic.B_Ranged_Generic_C.Muzzle Flash FX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SetWpnRarity(); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetWpnRarity // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void AddRandomScale(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AddRandomScale // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void UserConstructionScript(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void AnimateScopePostProcess__FinishedFunc(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AnimateScopePostProcess__FinishedFunc // (BlueprintEvent) // @ game+0xd6d38c
	void AnimateScopePostProcess__UpdateFunc(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AnimateScopePostProcess__UpdateFunc // (BlueprintEvent) // @ game+0xd6d38c
	void OnLoaded_4D1409A247BFDB4C074B628406FC7A72(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_4D1409A247BFDB4C074B628406FC7A72 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnLoaded_4DE6158742ED7EE528BC98A240A81632(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_4DE6158742ED7EE528BC98A240A81632 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnLoaded_3A9BBE884A5C5966375089938B7DC0CA(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_3A9BBE884A5C5966375089938B7DC0CA // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnLoaded_83457BA843174AC6288682A342EBEAD9(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_83457BA843174AC6288682A342EBEAD9 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnLoaded_5B08633343C4DA6FF40449A8A36357E4(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_5B08633343C4DA6FF40449A8A36357E4 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnPlayWeaponFireFX(bool bPersistentFire, bool bSecondaryFire); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnPlayWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnStopWeaponFireFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnStopWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnPlayReloadFX(enum class EFortReloadFXState ReloadStage); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnPlayReloadFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnSetTargeting(bool bNewIsTargeting); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnSetTargeting // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void K2_OnUnEquip(); // Function B_Ranged_Generic.B_Ranged_Generic_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void InitializeScopeVariables(); // Function B_Ranged_Generic.B_Ranged_Generic_C.InitializeScopeVariables // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Update Enemy Custom Depths(bool Enable Or Disable, int32_t StencilBufferValue); // Function B_Ranged_Generic.B_Ranged_Generic_C.Update Enemy Custom Depths // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnWeaponAttached(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void OnInitAlteration(struct UFortAlterationItemDefinition* NewAlteration); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnInitAlteration // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnInitCosmeticAlterations(struct FFortCosmeticModification CosmeticMod); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnInitCosmeticAlterations // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void ShellsON_(onPump)(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShellsON_(onPump) // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnEquippedWeaponDestory(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnEquippedWeaponDestory // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void SetWeaponPierceThrough(bool Enable, int32_t TargetLimit); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetWeaponPierceThrough // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void SetWeaponPierceThrough_ClientRep(bool Enable, int32_t TargetLimit); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetWeaponPierceThrough_ClientRep // (Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ReceiveBeginPlay(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void OnWeaponVisibilityChanged(bool bVisible, bool bSetForLocalControllerOnly); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnWeaponVisibilityChanged // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void HideWeaponMesh(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideWeaponMesh // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ShowWeaponMesh(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShowWeaponMesh // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void HideWeapon(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideWeapon // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ShowWeapon(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShowWeapon // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ReverseScopePP(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ReverseScopePP // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ResetDoonceScopeSound(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ResetDoonceScopeSound // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void UnhideThirdPersonStuff(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UnhideThirdPersonStuff // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void PlayScopePP(); // Function B_Ranged_Generic.B_Ranged_Generic_C.PlayScopePP // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void HideFirstPersonStuff(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideFirstPersonStuff // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void AbortScopeFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AbortScopeFX // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void HideThirdPersonStuff(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideThirdPersonStuff // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void UnhideFirstPersonStuffPart2(int32_t Which Call); // Function B_Ranged_Generic.B_Ranged_Generic_C.UnhideFirstPersonStuffPart2 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void UnhideFirstPersonStuffPart1(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UnhideFirstPersonStuffPart1 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ForceScopeFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ForceScopeFX // (Event|Public|BlueprintEvent) // @ game+0xd6d38c
	void BindFireRateChange(); // Function B_Ranged_Generic.B_Ranged_Generic_C.BindFireRateChange // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void PitchUpOnRateOfFireChange(float NewRateOfFire); // Function B_Ranged_Generic.B_Ranged_Generic_C.PitchUpOnRateOfFireChange // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ShellEjectionFixOn(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShellEjectionFixOn // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void Bind on Effects Quality(); // Function B_Ranged_Generic.B_Ranged_Generic_C.Bind on Effects Quality // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ShellEjectionOff(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShellEjectionOff // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ForceScopeBackImmediatly(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ForceScopeBackImmediatly // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnPlayImpactFX(struct FHitResult& HitResult, enum class EPhysicalSurface ImpactPhysicalSurface, struct UFXSystemComponent* SpawnedPSC); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnPlayImpactFX // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xd6d38c
	void OnStartOverheated(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnStartOverheated // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void LoadNiagaraMuzzleSoftObject(); // Function B_Ranged_Generic.B_Ranged_Generic_C.LoadNiagaraMuzzleSoftObject // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void OnApplyFireModeData(struct UFortWeaponFireModeData* FireModeData); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnApplyFireModeData // (Event|Protected|BlueprintEvent) // @ game+0xd6d38c
	void ScopeEffectDelay2(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ScopeEffectDelay2 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ScopeEffectDelay1(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ScopeEffectDelay1 // (BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
	void ExecuteUbergraph_B_Ranged_Generic(int32_t EntryPoint); // Function B_Ranged_Generic.B_Ranged_Generic_C.ExecuteUbergraph_B_Ranged_Generic // (Final|UbergraphFunction|HasDefaults) // @ game+0xd6d38c
	void onAimDownSightsChanged__DelegateSignature(bool AimDownsights); // Function B_Ranged_Generic.B_Ranged_Generic_C.onAimDownSightsChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xd6d38c
};


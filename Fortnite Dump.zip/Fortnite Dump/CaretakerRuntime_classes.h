// Class CaretakerRuntime.FortAIAnimInstance_Caretaker
// Size: 0x4b0 (Inherited: 0x450)
struct UFortAIAnimInstance_Caretaker : UFortAIAnimInstance {
	bool bIsMoving; // 0x448(0x01)
	float WalkPlayRate; // 0x44c(0x04)
	float AimOffsetCurve; // 0x450(0x04)
	bool bFootPhase_StopLeftPlant; // 0x454(0x01)
	bool bFootPhase_StopLeftPass; // 0x455(0x01)
	bool bFootPhase_StopRightPlant; // 0x456(0x01)
	bool bFootPhase_StopRightPass; // 0x457(0x01)
	float BreathingCurve; // 0x458(0x04)
	float MovingTreshold; // 0x45c(0x04)
	struct FName CurveName_AimOffsetCurve; // 0x460(0x08)
	struct FName CurveName_FootPhase; // 0x468(0x08)
	struct FName CurveName_BreathingCurve; // 0x470(0x08)
	struct FName SocketName_FX_Chest; // 0x478(0x08)
	struct FName ParamName_ChestSocketLocation; // 0x480(0x08)
	struct FName ParamName_ChestSocketVector; // 0x488(0x08)
	float FirstFootPhaseMin; // 0x490(0x04)
	float SecondFootPhaseMin; // 0x494(0x04)
	float ThirdFootPhaseMin; // 0x498(0x04)
	float FourthFootPhaseMin; // 0x49c(0x04)
	float FootPhaseMax; // 0x4a0(0x04)
	struct UFortAnimWorldStriderComponent* WorldStriderComponent; // 0x4a8(0x08)

	void SetDelayedMaterialParameters(); // Function CaretakerRuntime.FortAIAnimInstance_Caretaker.SetDelayedMaterialParameters // (Final|Native|Protected|BlueprintCallable) // @ game+0x3f8f3ac
	struct UFortAnimWorldStriderComponent* GetWorldStriderComponent(); // Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetWorldStriderComponent // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f8efe0
	float GetWalkSpeedWarpingValue(); // Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetWalkSpeedWarpingValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f8efb4
	float GetWalkPlayRateValue(); // Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetWalkPlayRateValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f8ef94
	float GetStartAnimPosition(); // Function CaretakerRuntime.FortAIAnimInstance_Caretaker.GetStartAnimPosition // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f8ef68
};

// Class CaretakerRuntime.FortAITask_CaretakerMove
// Size: 0x180 (Inherited: 0x180)
struct UFortAITask_CaretakerMove : UFortAbilityTask_MoveAI {
};

// Class CaretakerRuntime.FortAthenaCaretakerAIController
// Size: 0x520 (Inherited: 0x518)
struct AFortAthenaCaretakerAIController : AAthenaAIController {
	char pad_518[0x8]; // 0x518(0x08)

	void OnMovementModeChanged(struct ACharacter* CharacterOwner, enum class EMovementMode PreviousMovementMode, char PreviousCustomMode); // Function CaretakerRuntime.FortAthenaCaretakerAIController.OnMovementModeChanged // (Final|Native|Public) // @ game+0x3f8f008
	void DebugUpdate(float UpdateInterval); // Function CaretakerRuntime.FortAthenaCaretakerAIController.DebugUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x3f8eee4
};

// Class CaretakerRuntime.FortBTTask_CaretakerMoveTo
// Size: 0xe0 (Inherited: 0xb0)
struct UFortBTTask_CaretakerMoveTo : UBTTask_MoveTo {
	struct FBlackboardKeySelector FocalPointWhileMoving; // 0xb0(0x28)
	enum class EPathObstacleAction PathObstacleAction; // 0xd8(0x01)
	char pad_D9[0x3]; // 0xd9(0x03)
	char bEnableSlowdownAtGoal : 1; // 0xdc(0x01)
	char bMoveDirectlyTowards : 1; // 0xdc(0x01)
	char bStopAtGoal : 1; // 0xdc(0x01)
	char bFinishMoveOnOverlap : 1; // 0xdc(0x01)
	char pad_DC_4 : 4; // 0xdc(0x01)
	char pad_DD[0x3]; // 0xdd(0x03)
};

// Class CaretakerRuntime.FortNavigationFilter_Caretaker
// Size: 0x60 (Inherited: 0x48)
struct UFortNavigationFilter_Caretaker : UNavigationQueryFilter {
	float EndPointAcceptableRadius; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct UNavigationQueryFilter* EndPointFilterClass; // 0x50(0x08)
	char bEndPointReachTestIncludesAgentRadius : 1; // 0x58(0x01)
	char bEndPointReachTestIncludesGoalRadius : 1; // 0x58(0x01)
	char pad_58_2 : 6; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};


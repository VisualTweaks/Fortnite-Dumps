// BlueprintGeneratedClass FireAttachConditionHandler.FireAttachConditionHandler_C
// Size: 0x48 (Inherited: 0x48)
struct UFireAttachConditionHandler_C : UFortCurieElementAttachConditionHandlerFire {
};

